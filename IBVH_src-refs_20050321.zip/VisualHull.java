/**
 * This class represents the visual hull of an object in the scene. The hull
 * consists of a series of intervals along rays shot from the desired view.
 */

public class VisualHull {

	/** 2D array of <code>RayIntervals</code> representing the visual hull. */
	private RayIntervals[][] intervalImage;
	/** <code>Camera</code> of the desired view. */
	private Camera cam;
	/** Width of the interval image. */
	private int width;
	/** Height of the interval image. */
	private int height;

	/**
	 * Creates an empty <code>VisualHull</code>.
	 */
	public VisualHull() {
	}

	/**
	 * Creates an empty <code>VisualHull</code> with dimensions set to the
	 * dimensions of the image contained in the supplied <code>Camera</code>.
	 * Also creates <code>Ray3D</code>s from the projection point of the
	 * <code>Camera</code> through all the pixels of its image.
	 *
	 * @param c the camera of the desired view. Must contain an image.
	 */
	public VisualHull(Camera c) {
		this.cam = c;
		this.width = c.getImage().getWidth();
		this.height = c.getImage().getHeight();

		intervalImage = new RayIntervals[this.height][];
		for (int i = 0; i < this.height; i++) {
			intervalImage[i] = new RayIntervals[this.width];
			for (int j = 0; j < this.width; j++) {
				intervalImage[i][j] =
					new RayIntervals(Compute3DRay.compute3DRay(c, j, i));
			}
		}
	}

	/**
	 * Inserts the supplied <code>RayIntervals</code> into the specified
	 * position in the interval image.
	 *
	 * @param posX the x-position.
	 * @param posY the y-position.
	 * @param ri the <code>RayIntervals</code> object to insert.
	 */
	public void insertRayIntervals(int posX, int posY, RayIntervals ri) {
		intervalImage[posY][posX] = ri;
	}
	
	public RayIntervals getRayIntervals(int posX, int posY) {
		return intervalImage[posY][posX];
	}

	/**
	 * Transforms the complete visual hull by multiplying all its rays with
	 * the supplied matrix. Note that no rescaling of the intervals is performed
	 * so the matrix should imply any scaling either.
	 *
	 * @param t the transformation matrix.
	 */
	public void transform(Matrix4 t) {
		Ray3D temp;
		for (int row = 0; row < this.height; row++) {
			for (int col = 0; col < this.width; col++) {
				temp = intervalImage[row][col].getRay();
				Matrix4.mult(t, temp.getPoint());
				Matrix4.mult(t, temp.getDirection());
			}
		}
	}
	
	public void transformRayDirections(Matrix4 t) {
		Ray3D temp;
		for (int row = 0; row < this.height; row++) {
			for (int col = 0; col < this.width; col++) {
				temp = intervalImage[row][col].getRay();
				Matrix4.mult(t, temp.getDirection());
			}
		}
	}
	
	public void transformRayPositions(Matrix4 t) {
		Ray3D temp;
		for (int row = 0; row < this.height; row++) {
			for (int col = 0; col < this.width; col++) {
				temp = intervalImage[row][col].getRay();
				Matrix4.mult(t, temp.getPoint());
			}
		}
	}
}