/**
 * Class for handeling all vector computations
 */
public class Vector4 {

	public float x;
	public float y;
	public float z;
	public float w;
    

    /**
     * Default constructor
     */
    public Vector4() {
        this(0, 0, 0, 1);
    }
	
	/**
	 * Constructor
	 *
	 * @param x The vectors x coeficient
     * @param y The vectors y coeficient
     * @param z The vectors z coeficient
     * @param w The vectors w coeficient
     */
	public Vector4(float x, float y, float z, float w) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
	}

    /**
     * Constructor
     *
     * @param x The vectors x coeficient
     * @param y The vectors y coeficient
     * @param z The vectors z coeficient
     */
	public Vector4(float x, float y, float z) {
		this(x, y, z, 1);
	}

    /**
     * Copy constructor
     *
     * @param original The vector to be copied
     */
    public Vector4(Vector4 original) {
        this.x = original.x;
        this.y = original.y;
        this.z = original.z;
        this.w = original.w;
    }
    
	/**
	 * Set new values to the vector
	 *
	 * @param x x-value
	 * @param y y-value
	 * @param z z-value
	 * @param w w-value
	 */
	public void setVector4(float x, float y, float z, float w) {
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
	}
	
    /**
     * Negate a vector
     */
	public Vector4 negate() {
		this.x = -this.x;
		this.y = -this.y;
		this.z = -this.z;
		return this;
	}

     /**
     * Negate a vector
     *
     * @param v The vector to negate
     * @return a new vector = - v 
     */

	public static Vector4 negate(Vector4 v) {
		Vector4 v2 = new Vector4();
		v2.x = -v.x;
		v2.y = -v.y;
		v2.z = -v.z;
		return v2;
	}

    /**
     * Gets the length of a vector
     *
     * @return the lengt as a float
     */
	public float getLength() {
		return (float)Math.sqrt(Math.pow(this.x,2) + Math.pow(this.y,2) 
								+ Math.pow(this.z,2));
	}

    /**
     * Normalize
     *
     * @return the normalized vector
     */
	public Vector4 normalize() {
		float den = (float)Math.sqrt(Math.pow(this.x,2) + Math.pow(this.y,2)
							  		  + Math.pow(this.z,2));
		this.x = this.x / den;
		this.y = this.y / den;
		this.z = this.z / den;
		return this;
	}

    /**
     * Normalize
     *
     * @param n The vector to normalize
     * @return a new normalized vector
     */
	public Vector4 normalize(Vector4 n) {
		float den = (float) Math.sqrt(Math.pow(n.x,2) + Math.pow(n.y,2)
							  		  + Math.pow(n.z,2));

		this.x = n.x / den;
		this.y = n.y / den;
		this.z = n.z / den;
		return this;
	}

    /**
     * Compute the cross product between two vectors
     *
     * @param n The first vector
     * @param o The second vector
     * @return a new vector orthogonal to the others
     */
    public static Vector4 crossProduct(Vector4 n, Vector4 o){
        Vector4 cp = new Vector4();
        cp.x = n.y * o.z - n.z * o.y;
        cp.y = n.z * o.x - n.x * o.z;
        cp.z = n.x * o.y - n.y * o.x;
        return cp;
    }

    /**
     * Compute the cross product between two vectors
     *
     * @param o The second vector
     * @return the resulting vector
     */
    public Vector4 crossProduct(Vector4 o){
        this.x = this.y * o.z - this.z * o.y;
        this.y = this.z * o.x - this.x * o.z;
        this.z = this.x * o.y - this.y * o.x;
        return this;
    }
    
    /**
     * Compute the dot product of two vectors
     * @param v the second vector
     * @return the dotproduct in floating point
     */
    public float dotProduct(Vector4 v) {
    	float dot = this.x * v.x + this.y * v.y + this.z * v.z;
    	return dot;
    }
    
    /**
     * Adds a vector to current vector.
     *
     * @param b The vector to add
     * @return the resulting vector
     */
	public Vector4 add(Vector4 b) {
		this.x = this.x + b.x;
		this.y = this.y + b.y;
		this.z = this.z + b.z;
		return this;
	}

    /**
     * Subtracts a vector from current vector.
     *
     * @param b The vector to subtract
     * @return the resulting vector
     */
	public Vector4 sub(Vector4 b) {
		this.x = this.x - b.x;
		this.y = this.y - b.y;
		this.z = this.z - b.z;
		return this;
	}
	
    /**
     * Subtracts a vector from current vector.
     *
     * @param a The first vector
     * @param b The vector to subtract
     * @return a new resulting vector
     */
	public static Vector4 sub(Vector4 a, Vector4 b) {
		Vector4 v = new Vector4();
		v.x = a.x - b.x;
		v.y = a.y - b.y;
		v.z = a.z - b.z;
		return v;
	}


    /**
     * Projects a point in world coordinates to the origin cameras viewplane.
     * The coordinates are not converted to pixel coordinates.
     * The projected vector is NOT changed.
     *
     * @param vect3D the 3d-point to project
     * @param c the camera whose viewplane the point is to be projected to
     * @return the projected point as a vector
     */
	public Vector4 project(Vector4 vect3D, Camera c) {
		this.w = -vect3D.z/c.getFocalLength();
		this.x = vect3D.x / this.w;
		this.y = vect3D.y / this.w;
		this.z = vect3D.z / this.w;
		this.w = 1;
		return this;
	}

    /**
     * Projects a point in world coordinates to the origin cameras viewplane.
     * The coordinates are not converted to pixel coordinates.
     * The projected vector is changed.
     *
     * @param c the camera whose viewplane the point is to be projected to
     * @return the projected point as a vector
     */
	public Vector4 project(Camera c) {
		this.w = -this.z/c.getFocalLength();
		this.x = this.x / this.w;
		this.y = this.y / this.w;
		this.z = this.z / this.w;
		this.w = 1;
		return this;
	}

	/**
	 * Convert world coordinates to image coordinates, no projection. 
	 *
	 * @param c The camera containing the image coordinates.
	 * @return the converted vector
	 */
	public Vector4 world2pixel(Camera c) {
		double width = c.getImage().getWidth();
		double fov = c.getFov();
		double focalLength = c.getFocalLength();
		double factor = width / (2 * (focalLength * Math.tan(fov / 2)));
		this.x *= factor;
		this.y *= factor;
		return this;
	}

    /**
     * Convert image coordinates to world coordinates, no projection.
     * 
     * @param c The camera containing the image coordinates.
     * @return the converted vector
     */
	public Vector4 pixel2world(Camera c) {
		double width = c.getImage().getWidth();
		double fov = c.getFov();
		double focalLength = c.getFocalLength();
		double factor = width / (2 * (focalLength * Math.tan(fov / 2)));
		this.x /= factor;
		this.y /= factor;
		return this;
	}
}
