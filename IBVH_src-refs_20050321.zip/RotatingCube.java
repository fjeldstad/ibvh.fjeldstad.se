
import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import javax.swing.JPanel;
import java.awt.image.BufferedImage;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

/**
 * Class that shows a cube that the user can spin round the x-axis and the y-axis.
 * It represent moving the camera around the object
 */
public class RotatingCube extends JPanel implements MouseMotionListener {


	float theta;
	float phi;
	float b;
	float originalPhi;

	Camera c;

	Matrix4 rotMatrixX, rotMatrixY, rotMatrix, transToOrigo, transBack;

	Vector4 p1, p2, p3, p4, p5, p6, p7, p8, c1, c2, c3, c4, c5, c6, c7, c8;

	float m2p;

	Point2D.Float sumAngle;

	int height,width;
	int xPos,yPos;
	int oldY,oldX;
	int startX,startY;

	boolean firstTime;

	int[] xCordTop; int[] xCordBottom; int[] xCordLeft; int[] xCordRight; 
	int[] xCordFront; int[] xCordBack;
	
	int[] yCordTop; int[] yCordBottom; int[] yCordLeft; int[] yCordRight; 
	int[] yCordFront; int[] yCordBack;
	
	Color red, blue;

	private double t=0;
	private Image buf;

	/**
	 * Initialize all the parameters needed.
	 *
	 * @param ma the MouseAdapter sent from test()
	 */
	public void initStuff(MouseAdapter ma) {

		this.addMouseListener(ma);

		firstTime = true;

		red = new Color(255 , 0, 0);

		sumAngle = new Point2D.Float();

		xPos = 0;
		yPos = 0;
		oldX = -1;
		oldY = -1;

		this.addMouseMotionListener(this);

		height = this.getHeight()/2;
		width = this.getWidth()/2;
		b = 0.1f;

		p1 = new Vector4(b,b,b-1);
		p2 = new Vector4(-b,b,b-1);
		p3 = new Vector4(-b,-b,b-1);
		p4 = new Vector4(b,-b,b-1);
		p5 = new Vector4(b,b,-b-1);
		p6 = new Vector4(-b,b,-b-1);
		p7 = new Vector4(-b,-b,-b-1);
		p8 = new Vector4(b,-b,-b-1);

		c1 = new Vector4();
		c2 = new Vector4();
		c3 = new Vector4();
		c4 = new Vector4();
		c5 = new Vector4();
		c6 = new Vector4();
		c7 = new Vector4();
		c8 = new Vector4();

		xCordTop = new int[4];
		yCordTop = new int[4];
		xCordLeft = new int[4];
		yCordLeft = new int[4];
		xCordRight = new int[4];
		yCordRight = new int[4];
		xCordFront = new int[4];
		yCordFront = new int[4];
		xCordBack = new int[4];
		yCordBack = new int[4];
		xCordBottom = new int[4];
		yCordBottom = new int[4];

		Vector4 up = new Vector4(0,1,0);
		Vector4 pos = new Vector4(0,0,0);
		Vector4 dir = new Vector4(0,0,-1);
		BufferedImage bi = new BufferedImage(Camera.DEFAULT_IMAGE_WIDTH, 
											 Camera.DEFAULT_IMAGE_HEIGHT,
											 BufferedImage.TYPE_INT_RGB);
											 
		c = new Camera("",pos,dir,up,0.043456f,(float)(45*Math.PI/180),bi);

		/** Change meters in to pixels. */
		m2p = (float)(256/0.036);

		transToOrigo = new Matrix4();
		transBack = new Matrix4();

		Matrix4.getTranslateInstance(transToOrigo, 0f, 0f, 1f);
		Matrix4.getTranslateInstance(transBack, 0f, 0f, -1f);
	}

	/**
	 * Render the 3D graphics to the window using Java2D and JPanel for drawing
	 * Change the points in 3d space and project them down so it looks like a box
	 * spinning around.
	 */
	public void paintComponent(Graphics g) {


		super.paintComponent(g);
		g.setColor(Color.black);
		g.fillRect(0,0, getWidth(), getHeight());

		Graphics2D g2d = (Graphics2D)g;

		rotMatrixX = Matrix4.getRotateXInstance(phi);
		rotMatrixY = Matrix4.getRotateYInstance(theta);

		phi = 0;
		theta = 0;

		rotMatrix = rotMatrixX.mult(rotMatrixY, rotMatrixX);

		Matrix4.mult(transToOrigo, p1);
		Matrix4.mult(transToOrigo, p2);
		Matrix4.mult(transToOrigo, p3);
		Matrix4.mult(transToOrigo, p4);
		Matrix4.mult(transToOrigo, p5);
		Matrix4.mult(transToOrigo, p6);
		Matrix4.mult(transToOrigo, p7);
		Matrix4.mult(transToOrigo, p8);

		Matrix4.mult(rotMatrix, p1);
		Matrix4.mult(rotMatrix, p2);
		Matrix4.mult(rotMatrix, p3);
		Matrix4.mult(rotMatrix, p4);
		Matrix4.mult(rotMatrix, p5);
		Matrix4.mult(rotMatrix, p6);
		Matrix4.mult(rotMatrix, p7);
		Matrix4.mult(rotMatrix, p8);

		Matrix4.mult(transBack, p1);
		Matrix4.mult(transBack, p2);
		Matrix4.mult(transBack, p3);
		Matrix4.mult(transBack, p4);
		Matrix4.mult(transBack, p5);
		Matrix4.mult(transBack, p6);
		Matrix4.mult(transBack, p7);
		Matrix4.mult(transBack, p8);

		c1.x = p1.x;  c1.y = p1.y; c1.z = p1.z;
		c2.x = p2.x;  c2.y = p2.y; c2.z = p2.z;
		c3.x = p3.x;  c3.y = p3.y; c3.z = p3.z;
		c4.x = p4.x;  c4.y = p4.y; c4.z = p4.z;
		c5.x = p5.x;  c5.y = p5.y; c5.z = p5.z;
		c6.x = p6.x;  c6.y = p6.y; c6.z = p6.z;
		c7.x = p7.x;  c7.y = p7.y; c7.z = p7.z;
		c8.x = p8.x;  c8.y = p8.y; c8.z = p8.z;

		c1.project(c1, c);
		c2.project(c2, c);
		c3.project(c3, c);
		c4.project(c4, c);
		c5.project(c5, c);
		c6.project(c6, c);
		c7.project(c7, c);
		c8.project(c8, c);

		xCordFront[0] = Math.round(c1.x*m2p+width); 
		xCordFront[1] = Math.round(c2.x*m2p+width);
		xCordFront[2] = Math.round(c3.x*m2p+width); 
		xCordFront[3] = Math.round(c4.x*m2p+width);
		yCordFront[0] = Math.round(height-(-c1.y*m2p)); 
		yCordFront[1] = Math.round(height-(-c2.y*m2p));
		yCordFront[2] = Math.round(height-(-c3.y*m2p)); 
		yCordFront[3] = Math.round(height-(-c4.y*m2p));

		xCordBack[0] = Math.round(c6.x*m2p+width); 
		xCordBack[1] = Math.round(c5.x*m2p+width);
		xCordBack[2] = Math.round(c8.x*m2p+width); 
		xCordBack[3] = Math.round(c7.x*m2p+width);
		yCordBack[0] = Math.round(height-(-c6.y*m2p)); 
		yCordBack[1] = Math.round(height-(-c5.y*m2p));
		yCordBack[2] = Math.round(height-(-c8.y*m2p)); 
		yCordBack[3] = Math.round(height-(-c7.y*m2p));

		xCordLeft[0] = Math.round(c2.x*m2p+width); 
		xCordLeft[1] = Math.round(c6.x*m2p+width);
		xCordLeft[2] = Math.round(c7.x*m2p+width); 
		xCordLeft[3] = Math.round(c3.x*m2p+width);
		yCordLeft[0] = Math.round(height-(-c2.y*m2p)); 
		yCordLeft[1] = Math.round(height-(-c6.y*m2p));
		yCordLeft[2] = Math.round(height-(-c7.y*m2p)); 
		yCordLeft[3] = Math.round(height-(-c3.y*m2p));

		xCordRight[0] = Math.round(c1.x*m2p+width); 
		xCordRight[1] = Math.round(c4.x*m2p+width);
		xCordRight[2] = Math.round(c8.x*m2p+width); 
		xCordRight[3] = Math.round(c5.x*m2p+width);
		yCordRight[0] = Math.round(height-(-c1.y*m2p)); 
		yCordRight[1] = Math.round(height-(-c4.y*m2p));
		yCordRight[2] = Math.round(height-(-c8.y*m2p)); 
		yCordRight[3] = Math.round(height-(-c5.y*m2p));

		xCordTop[0] = Math.round(c1.x*m2p+width); 
		xCordTop[1] = Math.round(c5.x*m2p+width);
		xCordTop[2] = Math.round(c6.x*m2p+width); 
		xCordTop[3] = Math.round(c2.x*m2p+width);
		yCordTop[0] = Math.round(height-(-c1.y*m2p)); 
		yCordTop[1] = Math.round(height-(-c5.y*m2p));
		yCordTop[2] = Math.round(height-(-c6.y*m2p)); 
		yCordTop[3] = Math.round(height-(-c2.y*m2p));

		xCordBottom[0] = Math.round(c3.x*m2p+width); 
		xCordBottom[1] = Math.round(c7.x*m2p+width);
		xCordBottom[2] = Math.round(c8.x*m2p+width); 
		xCordBottom[3] = Math.round(c4.x*m2p+width);
		yCordBottom[0] = Math.round(height-(-c3.y*m2p)); 
		yCordBottom[1] = Math.round(height-(-c7.y*m2p));
		yCordBottom[2] = Math.round(height-(-c8.y*m2p)); 
		yCordBottom[3] = Math.round(height-(-c4.y*m2p));

		g2d.setColor(red);

		if(isFaceVisible(xCordFront[0], xCordFront[1], xCordFront[2], 
						 yCordFront[0], yCordFront[1], yCordFront[2])){
			g2d.drawPolygon(xCordFront, yCordFront, 4);
		}
		
		if(isFaceVisible(xCordBack[0], xCordBack[1], xCordBack[2], 
						 yCordBack[0], yCordBack[1], yCordBack[2])){
			g2d.drawPolygon(xCordBack, yCordBack, 4);
		}
		
		if(isFaceVisible(xCordRight[0], xCordRight[1], xCordRight[2], 
						 yCordRight[0], yCordRight[1], yCordRight[2])){
			g2d.drawPolygon(xCordRight, yCordRight, 4);
		}
		
		if(isFaceVisible(xCordLeft[0], xCordLeft[1], xCordLeft[2], 
						 yCordLeft[0], yCordLeft[1], yCordLeft[2])){
			g2d.drawPolygon(xCordLeft, yCordLeft, 4);
		}
		if(isFaceVisible(xCordTop[0], xCordTop[1], xCordTop[2], 
						 yCordTop[0], yCordTop[1], yCordTop[2])){
			g2d.drawPolygon(xCordTop, yCordTop, 4);
		}
		
		if(isFaceVisible(xCordBottom[0], xCordBottom[1], xCordBottom[2], 
						 yCordBottom[0], yCordBottom[1], yCordBottom[2])){
			g2d.drawPolygon(xCordBottom, yCordBottom, 4);
		}
	}

	public void mouseDragged(MouseEvent e) {
	}
	
	/**
	 * Reacts if the mouse is moved. The movement is used to change the points 
	 * in paintComponent()
	 */
	public void mouseMoved(MouseEvent e) {
		xPos = e.getX();
		yPos = e.getY();
		if (firstTime){
			startX = xPos;
			startY = yPos;
			theta = 0f;
			phi = 0f;
			firstTime = false;
		}
		else{
			theta = (float)(xPos - startX)/50;
			phi = (float)(yPos - startY)/50;

			if((originalPhi + phi) >= (float)Math.PI){
				phi = (float)Math.PI - originalPhi;
			}
			if((originalPhi + phi) <= 0){
				phi = 0 - originalPhi;
			}

			sumAngle.x = theta;
			sumAngle.y = phi;
			setOrginalCube();
		}

		repaint();
	}
	
	/**
	 * Checks if the polygon that the param belongs to is visible when it is 
	 * projected down.
	 */
	public boolean isFaceVisible(int x1, int x2, int x3, int y1, int y2, int y3){
		int zeta = (x2-x1) * (y3-y2) - (y2-y1) * (x3 - x2);
		if (zeta > 0){
			return true;
		}
		else{
			return false;
		}
	}
	
	/**
	 * Reset the angles with who the cube is spinned around its axis with to zero
	 */
	public void resetAngles() {
		sumAngle.x = 0f;
		sumAngle.y = 0f;
	}
	/**
	 * set the cube to its original position
	 */
	public void setOrginalCube(){
		p1.setVector4(b,b,b-1, 1f);
		p2.setVector4(-b,b,b-1,1f);
		p3.setVector4(-b,-b,b-1,1f);
		p4.setVector4(b,-b,b-1, 1f);
		p5.setVector4(b,b,-b-1,1f);
		p6.setVector4(-b,b,-b-1,1f);
		p7.setVector4(-b,-b,-b-1,1f);
		p8.setVector4(b,-b,-b-1,1f);
	}

	public void setFirstTime(boolean b){
		firstTime = b;
	}
	
	/**
	 * @return the angles with who the cube is spinned around its axis with
	 */
	public Point2D.Float getAngles(){
		return new Point2D.Float(-sumAngle.x, sumAngle.y);
	}
	
	/**
	 * Set the cameras present phi angle, this is used to make sure that
	 * the cube never can rotate so it will be upside down
	 */
	public void setCameraPhi(float p){
		originalPhi  = p;
	}
}
