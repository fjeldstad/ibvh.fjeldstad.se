import java.awt.geom.Point2D;
import java.awt.image.*;


public class Project3DRay {

//	private static final float BIG_NUM = 100.0f;
	private static Vector2 p1, p2;
	private static Ray2D ray;
	private static float imW, imH, imTop, imRight, imBottom, imLeft;
	private static float stepsize;
	private static Interval1D interval;

	/**
	 * Projects the supplied <code>Ray3D</code> to the supplied
	 * <code>Camera</code>, which is assumed to be located in origo looking
	 * down the negative Z-axis. The method then computes which part of the
	 * ray that intersects the silhouette of the camera's image. 
	 * If no part of the ray is contained within the silhouette, an
	 * empty interval is returned. In the current implementation, only single
	 * intervals are supported, limiting the objects to be convex.
	 *
	 * @param r the ray to project.
	 * @param c the camera to project to.
	 * @return the interval of the ray that is contained in the silhouette.
	 */
	public static Interval1D getProjectedInterval(Ray3D r, Camera c) {
		// Project two points on the ray to the view plane of the camera
		// and construct a Ray2D from the points.
		p1 = Vector2.project(r.getPosition(0), c);
		p2 = Vector2.project(r.getPosition(1000), c);
		ray = new Ray2D(p1, p2.sub(p1).normalize());;

		// Reposition the ray so that it sits on the edge of the camera's image
		// and points inwards into the image.
		repositionToImageEdge(ray, c);

		// Calculate stepsize, chosen so that it represents one pixel's width.
		stepsize = Vector2.pixel2World(1, c);

		// Step along the ray to find the start and end of the interval
		// contained within the silhouette.
		interval = new Interval1D();
		interval.makeEmpty();
		Vector2 currentPos;
		float tStart = 0;
		float tEnd = 0;
		int currentColor = 0;
		int step = 0;
		boolean searchForStart = true;
		boolean searchForEnd = true;
		for (; searchForStart; step++) {
			// Look for start of the interval
			currentPos = ray.getPosition(step * stepsize);
			currentPos.x = Math.round(Vector2.world2Pixel(currentPos.x, c) +
						   c.getImage().getWidth() / 2);
			currentPos.y = Math.round(c.getImage().getHeight() / 2 -
						   Vector2.world2Pixel(currentPos.y, c));
			currentColor = c.getRGB((int)currentPos.x, (int)currentPos.y);

			if (currentColor == Integer.MAX_VALUE) {
				// Pixel coordinates lay outside of the image
				searchForStart = false;
				searchForEnd = false;
			}
			else if (!isBackgroundColor(currentColor)) {
				interval.start = step * stepsize;
				searchForStart = false;
			}
		}
		for (; searchForEnd; step++) {
			// Look for end of the interval
			currentPos = ray.getPosition(step * stepsize);
			currentPos.x = Math.round(Vector2.world2Pixel(currentPos.x, c) +
				   		   c.getImage().getWidth() / 2);
			currentPos.y = Math.round(c.getImage().getHeight() / 2 -
						   Vector2.world2Pixel(currentPos.y, c));
			currentColor = c.getRGB((int)currentPos.x, (int)currentPos.y);
			if (currentColor == Integer.MAX_VALUE) {
				// Pixel coordinates lay outside of the image
				searchForEnd = false;
			}
			else if (isBackgroundColor(currentColor)) {
				interval.end = step * stepsize;
				searchForEnd = false;
			}
		}

		// Now the interval is in 2D space. The next step is to calculate
		// the corresponding 3D ray parameters.
		if (!interval.isEmpty()) {
			interval.start = backproject(r, ray.getPosition(interval.start), c);
			interval.end = backproject(r, ray.getPosition(interval.end), c);
		}

		return interval;
	}

	/*
	 * Repositions the supplied <code>Ray2D</code> so that its start point
	 * sits on the edge of the supplied <code>Camera</code>s image and its
	 * direction points towards the interior of the image. The ray is assumed
	 * to lie in the image plane of the camera.
	 *
	 * @param r the ray to reposition.
	 * @param c the camera to fetch the image from.
	 * @return true if the ray could be repositioned to the edge of the image,
	 *		   false otherwise.
	 */
	private static boolean repositionToImageEdge(Ray2D r, Camera c) {
		boolean hitImage = false;
		float newX, newY;
		Vector2 p = r.getPoint();
		Vector2 d = r.getDirection();
		Vector2 testOne = null;
		Vector2 testTwo = null;
		Vector2 testResult = null;

		// Read info about image dimensions
		imW = Vector2.pixel2World(c.getImage().getWidth()-1, c);
		imH = Vector2.pixel2World(c.getImage().getHeight()-1, c);
		imTop = imH/2;
		imRight = imW/2;
		imBottom = -imTop;
		imLeft = -imRight;

		// Figure out which edge to place the ray point on
		if (d.x >= 0 && d.y >= 0) {
			// Left or bottom edge
			testOne = r.getYForX(imLeft);
			testTwo = r.getXForY(imBottom);
		}
		else if (d.x < 0 && d.y < 0) {
			// Right or top edge
			testOne = r.getYForX(imRight);
			testTwo = r.getXForY(imTop);
		}
		else if (d.x >= 0 && d.y < 0) {
			// Left or top edge
			testOne = r.getYForX(imLeft);
			testTwo = r.getXForY(imTop);
		}
		else if (d.x < 0 && d.y >= 0) {
			// Right or bottom edge
			testOne = r.getYForX(imRight);
			testTwo = r.getXForY(imBottom);
		}
		testResult = Vector2.getShortest(testOne, testTwo);
		if (testResult != null) {
			r.setPoint(testResult);
			hitImage = true;
		}
		return hitImage;
	}

	/*
	 * Calculates the parameter for the supplied ray that will correspond to
	 * the supplied 2D point backprojected into 3D. The supplied camera is
	 * assumed to be positioned in origo looking down the negative Z-axis.
	 *
	 * @param r3D the ray in 3D space.
	 * @param p2D the point in 2D space.
	 * @param cam the camera looking at the 3D ray.
	 * @return the parameter for the (normalized) 3D ray that corresponds to the
	 *         backprojection of the supplied 2D point.
	 */
	private static float backproject(Ray3D r3D, Vector2 p2D, Camera cam) {
		Vector4 p, q, d;
		p = new Vector4(r3D.getPoint());
		q = new Vector4(p2D.x, p2D.y, -cam.getFocalLength());
		d = new Vector4(r3D.getDirection());
		float lengthOfEpipolarLine = p.getLength();
		p.normalize();
		q.normalize();
		d.normalize();

		return lengthOfEpipolarLine *
			   (float)Math.sin(Math.acos(q.dotProduct(p))) /
			   (float)Math.sin(Math.acos(d.dotProduct(q)));
	}
	
	/**
	 * Determines whether the supplied color is background or not. The color is
	 * considered background if its red component is in the interval [0, 10],
	 * its green component is in the interval [245, 255] and the blue component
	 * is in the interval [0, 10].
	 *
	 * @param color the color to test.
	 * @return true if the supplied color is a background color.
	 */
	public static boolean isBackgroundColor(int color) {
		
		// Extract rgb components
		int red = (color >> 16) & 0xff;
		int green = (color >> 8) & 0xff;
		int blue = color & 0xff;
		
		return (red <= 10 && green >= 245 && blue <= 10);
	}
	
	public static void printColor(int color) {
		
		// Extract rgb components
		int red = (color >> 16) & 0xff;
		int green = (color >> 8) & 0xff;
		int blue = color & 0xff;
		
		System.out.println(red + "\t" + green + "\t" + blue);
	}
}
