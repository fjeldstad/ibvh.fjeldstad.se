/**
 * This class represents a simple scalar one-dimensional interval, together
 * with a method for aquiring the intersection with another interval.
 */

public class Interval1D {

	/** Start point of the interval. */
	public float start;
	/** End point of the interval. */
	public float end;

	/**
	 * Creates a new <code>Interval1D</code> spanning the whole real axis.
	 */
	public Interval1D() {
		start = Float.NEGATIVE_INFINITY;
		end = Float.POSITIVE_INFINITY;
	}

	/**
	 * Creates a new <code>Interval1D</code> spanning the specified range.
	 *
	 * @param start the start point of the interval.
	 * @param end the end point of the interval.
	 */
	public Interval1D(float start, float end) {
		this.start = start;
		this.end = end;
	}

	/**
	 * Indicates whether this <code>Interval1D</code> is empty.
	 *
	 * @return true if the interval is empty, false otherwise.
	 */
	public boolean isEmpty() {
		return (Float.isNaN(start) || Float.isNaN(end));
	}

	/**
	 * Sets this <code>Interval1D</code> to the empty one.
	 */
	public void makeEmpty() {
		start = Float.NaN;
		end = Float.NaN;
	}
	
	/**
	 * Returns whether the <code>Interval1D</code> is valid. An interval is 
	 * considered valid if the end point is greater than the start point. An
	 * empty interval is also counted as a valid one.
	 *
	 * @return true if the interval is valid, false otherwise.
	 */
	public boolean isValid() {
		return ((this.start <= this.end) || this.isEmpty());
	}

	/**
	 * Performs the intersection operation between this interval and the
	 * supplied one. This interval is updated accordingly while the supplied
	 * one is left unchanged.
	 *
	 * @param other the interval to intersect this one with.
	 */
	public void intersection(Interval1D other) {
		
		if (this.isEmpty() || other.isEmpty()) {
			this.makeEmpty();
			
		}
		else if (this.isValid() == false || other.isValid() == false) {
			
			if (this.isValid() == false && other.isValid() == false) {
				this.makeEmpty();
				
			} 
			else if (this.isValid() == false) {
				this.start = other.start;
				this.end = other.end;
				
			} 
			else if (other.isValid() == false) {
				// Do nothing
			}
		}			
		else {

			float tempStart, tempEnd;
	
			// Check whether the intervals intersect at all
			if ((this.start < other.start && this.end < other.start) ||
				(this.start > other.end && this.end > other.end)) {
	
				this.makeEmpty();
			}
			else {
				if (this.start < other.start) {
					tempStart = other.start;
					if (this.end > other.end) {
						tempEnd = other.end;
					}
					else {
						tempEnd = this.end;
					}
				}
				else {
					tempStart = this.start;
					if (this.end > other.end) {
						tempEnd = other.end;
					}
					else {
						tempEnd = this.end;
					}
				}
				this.start = tempStart;
				this.end = tempEnd;
			}
		}
	}
	/**
	 * Performs the intersection operation between the two supplied
	 * <code>Interval1D</code>s. The result is returned as a new
	 * <code>Interval1D</code>.
	 *
	 * @param first the first interval.
	 * @param second the second interval.
	 * @return a new <code>Interval1D</code> as a result of the operation.
	 */
	public static Interval1D intersection(Interval1D first, Interval1D second) {

		Interval1D isect = new Interval1D(first.start, first.end);
		isect.intersection(second);
		return isect;
	}


}
