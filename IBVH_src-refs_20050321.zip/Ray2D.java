/** 
 * This class contains methods to handle Ray2D objects.
 */

public class Ray2D {

	
	Vector2 p = new Vector2();
	Vector2 d = new Vector2();

	/** 
	 * Constructor to create a <code>Ray2D</code>.
	 *
	 * @param p a <code>Vector2</code> containing the startposition of the ray.
	 * @param d a <code>Vector2</code> containing the direction of the ray.
	 */
	
	public Ray2D(Vector2 p, Vector2 d) {
		this.p = p;
		this.d = d;
	}
	
	/** 
	 * Constructor to create a <code>Ray2D</code>.
	 */
	public Ray2D() {
		this(new Vector2(), new Vector2());
	}

	/** 
	 * Sets a new direction to the <code>Ray2D</code>.
	 * 
	 * @param d a <code>Vector2</code> containing the new direction.
	 */
	public void setDirection(Vector2 d) {
		this.d = d;
	}

	/** 
	 * Sets a new starting point to the <code>Ray2D</code>.
	 * 
	 * @param p a <code>Vector2</code> containing the new startpoint.
	 */
	public void setPoint(Vector2 p) {
		this.p = p;
	}

	/**
	 * Returns the direction of the <code>Ray2D</code>.
	 *
	 * @return a <code>Vector2</code> containing the direction.
	 */
	public Vector2 getDirection() {
		return this.d;
	}

	/**
	 * Returns the starting point of the <code>Ray2D</code>.
	 *
	 * @return a <code>Vector2</code> containing the point.
	 */
	public Vector2 getPoint() {
		return this.p;
	}

	/** 
	 * Returns a position along a <code>Ray2D</code>
	 *
	 * @param t the parameter
	 *
	 * @return a <code>Vector2</code> containing the position.
	 */
	public Vector2 getPosition(float t) {
		return new Vector2(this.p.x + t*this.d.x, this.p.y + t*this.d.y);
	}

	/** 
	 * Returns a position along a <code>Ray2D</code> knowing the x-value
	 *
	 * @param x the x-value of the position
	 *
	 * @return a <code>Vector2</code> containing the position.
	 */
	public Vector2 getYForX(float x) {
		if (d.x == 0) {
			return null;	// Avoid division by zero
		} else {
			float t = (x - p.x) / d.x;
			return new Vector2(x, p.y + t * d.y);
		}
	}

	/** 
	 * Returns a position along a <code>Ray2D</code> knowing the y-value
	 *
	 * @param y the y-value of the position
	 *
	 * @return a <code>Vector2</code> containing the position.
	 */
	public Vector2 getXForY(float y) {
		if (d.y == 0) {
			return null;	// Avoid division by zero
		} else {
			float t = (y - p.y) / d.y;
			return new Vector2(p.x + t * d.x, y);
		}
	}
}
