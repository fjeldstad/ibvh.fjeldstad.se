/** 
 * This class contains methods to handle <code>Vector2</code> objects.
 */
public class Vector2 {

	public float x, y;


	/** 
	 * Constructor to create a <code>Vector2</code>.
	 */	
	public Vector2() {
		this.x = 0;
		this.y = 0;
	}
	
	/** 
	 * Constructor to create a <code>Vector2</code>.
	 *
	 * @param x the x value.
	 * @param y the y value.
	 */
	public Vector2(float x, float y) {
		this.x = x;
		this.y = y;
	}
	
	/** 
	 * Method to copy a <code>Vector2</code> object.
	 *
	 * @param v the <code>Vector2</code> that should be copied.
	 */
	public Vector2(Vector2 v) {
		this.x = v.x;
		this.y = v.y;
	}
	
	/** 
	 * Method to copy a the first 2 components of a <code>Vector4</code> object
	 * to a <code>Vector2</code> object.
	 *
	 * @param v the <code>Vector4</code> of which the first 2 component shall be
	 * copied.
	 */
	public Vector2(Vector4 v) {
		this.x = v.x;
		this.y = v.y;
	}

	/**
	 * Static method to add two <code>Vector2</code>.
	 * 
	 * @param v1 a <code>Vector2</code>.
	 * @param v2 a <code>Vector2</code>.
	 *
	 * @return A new <code>Vector2</code>.
	 */
	 
	public static Vector2 add(Vector2 v1, Vector2 v2) {
		return new Vector2(v1.x + v2.x, v1.y + v2.y);
	}

	/**
	 * Method to add a <code>Vector2</code> to an existing <code>Vector2</code>.
	 * 
	 * @param v a <code>Vector2</code>.
	 *
	 * @return a <code>Vector2</code>.
	 */
	public Vector2 add(Vector2 v) {
		this.x += v.x;
		this.y += v.y;
		return this;
	}
	
	/**
	 * Static method to subtract a <code>Vector2</code> from another
	 * 
	 * @param v1 a <code>Vector2</code>
	 * @param v2 a <code>Vector2</code> to subtract
	 *
	 * @return A new <code>Vector2</code>
	 */
	public static Vector2 sub(Vector2 v1, Vector2 v2) {
		return new Vector2(v1.x - v2.x, v1.y - v2.y);
	}
	
	/**
	 * Method to subtract a <code>Vector2</code> from an current 
	 * <code>Vector2</code>.
	 * 
	 * @param v a <code>Vector2</code> that should be subtracted.
	 *
	 * @return a <code>Vector2</code>.
	 */
	public Vector2 sub(Vector2 v) {
		this.x -= v.x;
		this.y -= v.y;
		return this;
	}

	/**
	 * Method that returns the length of current <code>Vector2</code>.
	 *
	 *  @return the length.
	 */
	public float getLength() {
		return (float)Math.sqrt(this.x * this.x + this.y * this.y);
	}

	/**
	 * Method to normalize the current <code>Vector2</code>.
	 * 
	 * @return the normalized <code>Vector2</code>.
	 */
	public Vector2 normalize() {
		float len = this.getLength();
		this.x /= len;
		this.y /= len;
		return this;
	}
	
	/**
	 * Method to project a <code>Vector4</code> onto an imageplane
	 * 
	 * @param c the Camera containing the imageplane
	 * @param p the <code>Vector4</code> to project
	 *
	 * @return the resulting <code>Vector2</code>
	 */
	public static Vector2 project(Vector4 p, Camera c) {
		float f = c.getFocalLength();
		float w = Math.abs(p.z / f);
		return new Vector2(p.x / w, p.y / w);
	}

	/**
	 * Method to convert a world position (1D) to image coordinates. 
	 *
	 * @param c the camera containing the image coordinates.
	 * @param world the point in the world.
	 * 
	 * @return the converted point
	 */
	public static int world2Pixel(float world, Camera c) {
		float width = c.getImage().getWidth();
		float fov = c.getFov();
		float focalLength = c.getFocalLength();
		float factor = width / (2 * (focalLength * (float)Math.tan(fov / 2)));
		return Math.round(world * factor);
	}

	/**
	 * Method to convert a image coordinate (1D) to image coordinates. 
	 *
	 * @param c the camera containing the image coordinates.
	 * @param pixel the point in the image (1D).
	 * 
	 * @return the converted point
	 */
	public static float pixel2World(int pixel, Camera c) {
		float width = c.getImage().getWidth();
		float fov = c.getFov();
		float focalLength = c.getFocalLength();
		float factor = width / (2 * (focalLength * (float)Math.tan(fov / 2)));
		return pixel / factor;
	}

	/**
	 * Returns the shortest of the two supplied vectors. If the vectors are
	 * of equal length, the second one is returned.
	 *
	 * @param v1 the first vector.
	 * @param v2 the second vector.
	 * @return the shortest of the two vectors or the second one if they are
	 * 		   of equal length.
	 */
	public static Vector2 getShortest(Vector2 v1, Vector2 v2) {
		if (v1 == null && v2 != null) {
			return v2;
		}
		else if (v1 != null && v2 == null) {
			return v1;
		}
		else if (v1 == null && v2 == null) {
			return null;
		}
		else {
			if (v1.getLength() < v2.getLength()) {
				return v1;
			}
			else {
				return v2;
			}
		}
	}

}
