import java.util.Vector;

/**
 * This class takes care of all the steps of constructing a visual hull
 * from a set of reference views and a desired view.
 */
public class VisualHullCreator implements Runnable {

	/** Reference views */
	private Vector refViews;
	/** Desired view */
	private Camera desView;
	/** The actual visual hull */
	private VisualHull vh;
	private boolean running;
	private int progress;
	private float progressStep;
	private String note;
	public Thread thread;

	private static final int BG_COLOR = ((0xff << 24) & 0xffffffff) |
										(((0xff & 0) << 16) & 0xffffffff) |
										(((0xff & 255) << 8) & 0xffffffff) |
										((0xff & 0) & 0xffffffff);

	private static final int BLACK = ((0xff << 24) & 0xffffffff) |
									 (((0xff & 0) << 16) & 0xffffffff) |
									 (((0xff & 0) << 8) & 0xffffffff) |
									 ((0xff & 0) & 0xffffffff);

	/**
	 * Creates a <code>VisualHullCreator</code> with the supplied reference
	 * views and desired view.
	 *
	 * @param refs a <code>Vector</code> of <code>Camera</code>s representing
	 *             the reference views of the scene.
	 * @param desired a <code>Camera</code> representing the desired view.
	 */
	public VisualHullCreator(Vector refs, Camera desired) {

		this.running = false;
		this.progress = 0;
		this.note = "";
		this.refViews = refs;
		this.desView = desired;
		this.vh = new VisualHull(desView);
	}

	/**
	 * Returns whether the process is running.
	 *
	 * @return true if the process is running, false otherwise.
	 */
	public boolean isRunning() {
		return this.running;
	}

	/**
	 * Starts the calculation of the visual hull.
	 */
	public void startProcess() {
		this.running = true;
		this.progress = 0;
		thread = new Thread(this);
		thread.setPriority(Thread.MIN_PRIORITY);
		thread.start();
	}

	/**
	 * Interrupts the calculation of the visual hull at the next loop.
	 */
	public void stopProcess() {
		this.running = false;
	}

	/**
	 * Returns how far the calculation of the visual hull has progressed.
	 * This is indicated as a nuber between 0 and 100.
	 *
	 * @return the progress of the calculation (number between 0 and 100).
	 */
	public int getProgress() {
		return this.progress;
	}

	/**
	 * Returns a <code>String</code> that describes what phase the calculations
	 * are in.
	 *
	 * @return a <code>String</code> describing the state of the calculations.
	 */
	public String getNote() {
		return this.note;
	}

	/**
	 * Returns whether the calculation of the visual hull is finished.
	 *
	 * @return true if the calculation is finished, false otherwise.
	 */
	public boolean isFinished() {
		return (progress == 100);
	}

	/**
	 * Returns the <code>VisualHull</code> object contained in the
	 * <code>VisualHullCreator</code>.
	 *
	 * @return the visual hull.
	 */
	public VisualHull getVisualHull() {
		return this.vh;
	}

	public void run() {
		// Calculate everything
		// Don't forget to update this.progress

		Camera c;
		RayIntervals ri;
		Matrix4 rot, iRot, trans, iTrans;
		Ray3D r;
		int notEmpty = 0;
		int camWidth = 0;
		int camHeight = 0;

		progressStep = 1.0f/(float)(refViews.size()+1);

		for (int camNum = 0; camNum < refViews.size(); camNum++) {

			c = (Camera) refViews.elementAt(camNum);

			this.note = "Intersecting rays with " + c.getTitle();

			CameraRot.createMatrices(c);

			rot = CameraRot.getRotMatrix();
			iRot = CameraRot.getInvRotMatrix();
			trans = CameraRot.getTlMatrix();
			iTrans = CameraRot.getInvTlMatrix();

			camWidth = desView.getImage().getWidth();
			camHeight = desView.getImage().getHeight();

			for (int posY = 0; posY < camHeight; posY++) {
				for (int posX = 0; posX < camWidth; posX++) {

					this.progress = (int)(100 * ((float)camNum *
						(float)progressStep + (float)progressStep *
						((float)posY * (float)camWidth + posX) /
						((float)camWidth * (float)camHeight)));

					ri = vh.getRayIntervals(posX, posY);
					r = ri.getRay();

					// Translate ray position
					Matrix4.mult(trans, ri.getRay().getPoint());

					// Rotate ray position and direction
					Matrix4.mult(rot, r.getPoint());
					Matrix4.mult(rot, r.getDirection());

					// Check if the angle between the ray direction and
					// the view direction of the camera is close to 0 degrees
					// or 180 degrees. If so, skip interval calculation for
					// this ray.
					float angle = (float)Math.toDegrees(Math.acos(
								   (new Vector4(0, 0, -1)).dotProduct(
								    r.getDirection())));

					if (angle >= 20 && angle <= 160) {

						((Interval1D) ri.getIntervals().elementAt(0)).intersection(
							Project3DRay.getProjectedInterval(r, c));
					}

					// Rotate ray position and direction back
					Matrix4.mult(iRot, r.getPoint());
					Matrix4.mult(iRot, r.getDirection());
					// Translate ray position back
					Matrix4.mult(iTrans, r.getPoint());

					thread.yield();
				}
			}
		}

		// Perform shading
		this.note = "Shading the visual hull";
		
		// Create a depth map of the visualhull
		createDepthMap(vh, desView);
		
		// Shade our visual hull
		// shade(vh,refViews,desView);
		
		this.progress = 100;
	}

	/**
	 * Depth map for the visual hull.
	 *
	 * @param vh The visual hull.
	 * @param novel The novel camera.
	 */
	 private void createDepthMap(VisualHull vh, Camera novel) {

	 	float near = Float.NEGATIVE_INFINITY;
	 	float far = Float.POSITIVE_INFINITY;
	 	float intensity;
	 	int tempColor;
	 	Vector4 point;
		RayIntervals ri;
		Interval1D interval;

		CameraRot.createMatrices(novel);
		Matrix4 rotationMatrix = CameraRot.getRotMatrix();
		Matrix4 translationMatrix = CameraRot.getTlMatrix();

		Matrix4.mult(translationMatrix, novel.getPos());
		Matrix4.mult(rotationMatrix, novel.getDir());

		int camWidth = novel.getImage().getWidth();
		int camHeight = novel.getImage().getWidth();

	 	// Find maximum and minimum depth
		for (int posY = 0; posY < camHeight; posY++) {
			for (int posX = 0; posX < camWidth; posX++) {

				progress += 50 * progressStep * (float)(posY * camWidth + posX)/
												  (float)(camWidth * camHeight);

				ri = vh.getRayIntervals(posX, posY);
				interval = (Interval1D) ri.getIntervals().elementAt(0);
				if (!interval.isEmpty()) {
					point = ri.getRay().getPosition(interval.start);

					Matrix4.mult(translationMatrix, point);
					Matrix4.mult(rotationMatrix, point);

					if(point.z > near) {
						near = point.z;
					}
					if(point.z < far) {
						far = point.z;
					}

				}

			}
		}

		// Shade the depth map
		for (int posY = 0; posY < camHeight; posY++) {
			for (int posX = 0; posX < camWidth; posX++) {

				progress += 50 * progressStep * (float)(posY * camWidth + posX)/
												  (float)(camWidth * camHeight);

				ri = vh.getRayIntervals(posX, posY);
				interval = (Interval1D) ri.getIntervals().elementAt(0);
				if (interval.isEmpty()) {
					novel.getImage().setRGB(posX,posY,BLACK);
					continue;
				}
				point = ri.getRay().getPosition(interval.start);

				Matrix4.mult(translationMatrix, point);
				Matrix4.mult(rotationMatrix, point);
				intensity = 255 - (near - point.z) * 200 / (near - far);

				tempColor =	((0xff << 24) & 0xffffffff) |
							(((0xff & (int)intensity) << 16) & 0xffffffff) |
							(((0xff & (int)intensity) << 8) & 0xffffffff) |
							((0xff & (int)intensity) & 0xffffffff);

				novel.getImage().setRGB(posX,posY,tempColor);
			}
		}
		rotationMatrix = CameraRot.getInvRotMatrix();
		translationMatrix = CameraRot.getInvTlMatrix();

		Matrix4.mult(rotationMatrix, novel.getDir());
		Matrix4.mult(translationMatrix, novel.getPos());
	 }
	 
	 /** A method to shade our visual hull
	  *
	  *	@param vh the <code>visual hull</code>
	  * @param refs a vector containing the reference cameras
	  * @param desView a camera containing our novel view
	  */	 
	 private void shade(VisualHull vh, Vector refs, Camera desView) {

		Camera c;
		RayIntervals ri;
		Ray3D r;
		Interval1D interval;
		Matrix4 rotationMatrix;
		Matrix4 translationMatrix;
		Vector4 point;
		Vector4 desPos;
		Vector4 dir1;
		Vector4 dir2;
		float t;
		float angle = 0;
		float bestAngle = -1;
		int bestCamera = 0;
		int pixel;
		Vector2 projectedPoint = new Vector2();

		desPos = desView.getPos();

		// For every ray in the novel image
		for (int posY = 0; posY < desView.getImage().getHeight(); posY++) {
			for (int posX = 0; posX < desView.getImage().getWidth(); posX++) {

				ri = vh.getRayIntervals(posX, posY);
				r = ri.getRay();
				interval = (Interval1D) ri.getIntervals().elementAt(0);
				
				// If the intreval in the current position is empty
				if (interval.isEmpty()) {
					// Set background color
					desView.getImage().setRGB(0,0,0);
				}
				else {
                    
                    // Get the intervals startpoint in 3d                    
					t = interval.start;
                    // Reference camera position
					point = r.getPosition(t);
                    // Epipolar line betwwen reference and novel camera
					dir1 = Vector4.sub(point, desPos);
					dir1.normalize();
					
					bestAngle = -1;
                    
                    // Find the camera, which direction is closest to the novel
                    // view direction
					for (int camNum = 0; camNum < refs.size(); camNum++) {
						c = (Camera) refs.elementAt(camNum);
						dir2 = Vector4.sub(point, c.getPos());
						dir2.normalize();
						angle = (float)Math.acos(dir1.dotProduct(dir2));

						if(bestAngle == -1) {
							bestCamera = camNum;
							bestAngle = angle;
						}
						else if(angle < bestAngle) {
							bestAngle = angle;
							bestCamera = camNum;
						}
					}
					
					// Get the best camera
					c = (Camera) refs.elementAt(bestCamera);
					
					// Make matrices to rotate the camera to origin and it's
					// direction to 0,0,-1
					CameraRot.createMatrices(c);
					rotationMatrix = CameraRot.getRotMatrix();
					translationMatrix = CameraRot.getTlMatrix();
					
					// Rotate the camera and do corresponding rotation on the
					// interval point
					Matrix4.mult(translationMatrix, c.getPos());
					Matrix4.mult(translationMatrix, point);
					Matrix4.mult(rotationMatrix, c.getDir());
					Matrix4.mult(rotationMatrix, point);
                    
                    // Project the interval point to the cameras viewplane
					projectedPoint = Vector2.project(point, c);
					
					// Pick pixel coordinates					
					projectedPoint.x = Math.round(
								       Vector2.world2Pixel(projectedPoint.x, c)
								       + c.getImage().getWidth() / 2);
					projectedPoint.y = Math.round(
									   c.getImage().getHeight() / 2 - 
									  Vector2.world2Pixel(projectedPoint.y, c));
					
					pixel = c.getRGB((int)projectedPoint.x,
					                 (int)projectedPoint.y);

                    // If the picked pixel is outside of the object or of 
                    // background color, set it to black.
					if(Project3DRay.isBackgroundColor(pixel) || 
					   pixel == Integer.MAX_VALUE) {
					   	
						pixel = BLACK;
					}
                    
					desView.getImage().setRGB(posX, posY, pixel);

					rotationMatrix = CameraRot.getInvRotMatrix();
					translationMatrix = CameraRot.getInvTlMatrix();
                    // Rotate the camera back to it's previous location and
                    // direction.
					Matrix4.mult(rotationMatrix, c.getDir());
					Matrix4.mult(translationMatrix, c.getPos());

				}
			}
		}

	}
}