/** 
 * This class contains methods to handle Ray3D objects.
 */
public class Ray3D {

	Vector4 p;
	Vector4 d;

	/** 
	 * Constructor to create a <code>Ray3D</code>.
	 *
	 * @param p a <code>Vector4</code> containing the startposition of the ray.
	 * @param d a <code>Vector4</code> containing the direction of the ray.
	 */
	public Ray3D(Vector4 p, Vector4 d) {
		this.p = p;
		this.d = d;
	}
	
	/** 
	 * Constructor to create a <code>Ray3D</code>.
	 */
	public Ray3D() {
		this(new Vector4(), new Vector4(0.0f, 0.0f, 0.0f, 0.0f));
	}

	/** 
	 * Sets a new direction to the <code>Ray3D</code>.
	 * 
	 * @param d a <code>Vector4</code> containing the new direction.
	 */
	public void setDirection(Vector4 d) {
		this.d = d;
	}

	/** 
	 * Sets a new starting point to the <code>Ray3D</code>.
	 * 
	 * @param p a <code>Vector4</code> containing the new startpoint.
	 */
	public void setPoint(Vector4 p) {
		this.p = p;
	}

	/**
	 * Returns the direction of the <code>Ray3D</code>.
	 *
	 * @return a <code>Vector4</code> containing the direction.
	 */
	public Vector4 getDirection() {
		return d;
	}

	/**
	 * Returns the starting point of the <code>Ray3D</code>.
	 *
	 * @return a <code>Vector4</code> containing the point.
	 */
	public Vector4 getPoint() {
		return p;
	}

	/** 
	 * Returns a position along a <code>Ray3D</code>
	 *
	 * @param t the parameter
	 *
	 * @return a <code>Vector4</code> containing the position.
	 */
	public Vector4 getPosition(float t) {
		return new Vector4(p.x + t*d.x,
						   p.y + t*d.y,
						   p.z + t*d.z);
	}

}