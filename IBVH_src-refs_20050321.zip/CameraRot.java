/**
 * This is a class that contains methods to create transform matrices that
 * can transform our camera to (0,0,0), its direction to (0,0,-1) and its
 * up direction to (0,1,0)
 *
 */

public class CameraRot {

	static Matrix4 rotMatrix, invRotMatrix, tlMatrix, invTlMatrix;
	static Vector4 desiredDir;

	/**
	 * This is a static method that creates the transformation matrices
	 * used to transform the objects in 3D space.
	 *
	 * @param c the <code>Camera</code>
	 */
	public static void createMatrices(Camera c) {
		desiredDir = new Vector4(0, 0, -1);
		calculateMatrices(c, desiredDir);
	}

	public static void createMatrices(Camera c, Vector4 desiredDir) {
		calculateMatrices(c, desiredDir);
	}
	
	public static void calculateMatrices(Camera c, Vector4 desiredDir){

		Vector4 dir = c.getDir();
		Vector4 up = c.getUp();
		Vector4 rotAxis;
		Vector4 upTemp = new Vector4(up.x, up.y, up.z);
		Vector4 pos = c.getPos();
		rotMatrix = new Matrix4();
		invRotMatrix = new Matrix4();
		tlMatrix = new Matrix4();
		invTlMatrix = new Matrix4();
		float angle;

		Matrix4.getTranslateInstance(tlMatrix, -pos.x, -pos.y, -pos.z);
		Matrix4.getTranslateInstance(invTlMatrix, pos.x, pos.y, pos.z);

		//Special cases if the diretion and desired direction are parallel
		if(dir.dotProduct(desiredDir) == 1) {
			angle = 0;
			rotAxis = new Vector4();
		}
		else if(dir.dotProduct(desiredDir) == -1) {
			angle = (float)Math.PI;
			rotAxis = new Vector4(0,1,0);
		}
		else {
			angle = (float)Math.acos(dir.dotProduct(desiredDir));
			rotAxis = Vector4.crossProduct(dir,desiredDir);
			rotAxis.normalize();
		}

		float cos = (float)Math.cos(angle);
		float sin = (float)Math.sin(angle);

		float u = rotAxis.x;
		float v = rotAxis.y;
		float w = rotAxis.z;

		rotMatrix.a11 =      cos + u*u*(1-cos);
		rotMatrix.a21 =  w * sin + v*u*(1-cos);
		rotMatrix.a31 = -v * sin + w*u*(1-cos);
		rotMatrix.a12 = -w * sin + u*v*(1-cos);
		rotMatrix.a22 =      cos + v*v*(1-cos);
		rotMatrix.a32 =  u * sin + w*v*(1-cos);
		rotMatrix.a13 =  v * sin + u*w*(1-cos);
		rotMatrix.a23 = -u * sin + v*w*(1-cos);
		rotMatrix.a33 =      cos + w*w*(1-cos);

		cos = (float)Math.cos(-angle);
		sin = (float)Math.sin(-angle);

		invRotMatrix.a11 =      cos + u*u*(1-cos);
		invRotMatrix.a21 =  w * sin + v*u*(1-cos);
		invRotMatrix.a31 = -v * sin + w*u*(1-cos);
		invRotMatrix.a12 = -w * sin + u*v*(1-cos);
		invRotMatrix.a22 =      cos + v*v*(1-cos);
		invRotMatrix.a32 =  u * sin + w*v*(1-cos);
		invRotMatrix.a13 =  v * sin + u*w*(1-cos);
		invRotMatrix.a23 = -u * sin + v*w*(1-cos);
		invRotMatrix.a33 =      cos + w*w*(1-cos);

		//Calculates the z angle using a temp vector.
		Matrix4.mult(rotMatrix, upTemp);
		float zAngle = (float)Math.atan2(upTemp.x, upTemp.y);

		rotMatrix = Matrix4.mult(Matrix4.getRotateZInstance(zAngle), rotMatrix);
		invRotMatrix = Matrix4.mult(invRotMatrix, 
									Matrix4.getRotateZInstance(-zAngle));

	}

	/**
	 * This method returns the rotation matrix,
	 * rotating the camera direction to (0,0,-1)
	 * and up direction to (0,1,0)
	 *
	 * @return A rotation matrix
	 */

	public static Matrix4 getRotMatrix() {
		return rotMatrix;
	}

	/**
	 * This method returns the inverse rotation matrix
	 * rotating the camera direction and up direction
	 * to its initial direction.
	 *
	 * @return A rotation matrix
	 */

	public static Matrix4 getInvRotMatrix() {
		return invRotMatrix;
	}

	/**
	 * This method returns the translation matrix that translates to (0,0,0).
	 *
	 * @return A translation matrix
	 */

	public static Matrix4 getTlMatrix() {
		return tlMatrix;
	}

	/**
	 * This method returns the translation matrix that translates
	 * to original position.
	 *
	 * @return A translation matrix
	 */

	public static Matrix4 getInvTlMatrix() {
		return invTlMatrix;
	}

}
