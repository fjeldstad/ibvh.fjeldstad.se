import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Vector;
import java.awt.geom.Point2D;
import java.applet.*;
import java.net.URL;
import java.net.MalformedURLException;

/**
 * This is the main class of the project, containing the GUI among other
 * components. Note that this is the applet version, and therefore lacks
 * features like customizable reference cameras etc. For the standalone
 * application, see IBVHApplication.java.
 */

public class IBVHApplet extends Applet implements TreeSelectionListener {

	/** The font used in the GUI */
	public static final Font DEFAULT_FONT = new Font("Verdana", Font.PLAIN, 11);

	private JPanel mainpane;
	private JScrollPane treepane;
	private JTree tree;
	private DefaultTreeModel treeModel;
	private DefaultMutableTreeNode sceneNode, refViewsNode, novelViewNode;
	private Vector refCameras;
	private Camera novelCamera;
	private VisualHullCreator vhcreator;
	private Timer timer;
	private ProgressMonitor progressMonitor;
	private RotatingCube rotatingCube;
	private MouseClickListener clickListener;

	public ImagePanel viewpane;
	private BufferedImage currentImage;

	private CardLayout viewdeck;
	private JPanel viewpanel;

	private boolean cubeVisible = false;

	private float originalPhi, originalTheta, phi, theta;
	private Point2D.Float sumAngle;
	private Vector4 sideVector, upVector, projPoint, upY,
		    tempDirection, tempPoint;
	private Matrix4 rotateMatrix, translateMatrix, rotTransMatrix;

	/**
	 * Initializes the GUI and data representation.
	 */
	public void init() {

		mainpane = new JPanel();
		this.add(mainpane);
		this.setLayout(null);

		refCameras = new Vector(10, 10);

		novelCamera = new Camera("Novel view",
								 new Vector4(0.5f, 0, 0),
								 new Vector4(-1, 0, 0),
								 new Vector4(0, 1, 0),
								 0.043456f,
								 45,
								 new BufferedImage(Camera.DEFAULT_IMAGE_WIDTH,
								  	Camera.DEFAULT_IMAGE_HEIGHT,
								  	BufferedImage.TYPE_INT_RGB));

		vhcreator = new VisualHullCreator(refCameras, novelCamera);

		timer = new Timer(1000, new TimerListener());

		clickListener = new MouseClickListener();

		rotatingCube = new RotatingCube();
		rotatingCube.setBackground(new Color(0, 0, 0));
		rotatingCube.setSize(256, 256);
		rotatingCube.initStuff(clickListener);

		sceneNode = new DefaultMutableTreeNode("Scene");
		refViewsNode = new DefaultMutableTreeNode("Reference views");
		novelViewNode = new DefaultMutableTreeNode(novelCamera);

		sceneNode.add(refViewsNode);
		sceneNode.add(novelViewNode);

		treeModel = new DefaultTreeModel(sceneNode);
		tree = new JTree(treeModel);
		tree.setFont(DEFAULT_FONT);
		tree.setEditable(false);
		tree.addTreeSelectionListener(this);

		treepane = new JScrollPane(tree);
		treepane.setBounds(10, 10, 200, 256);
		mainpane.add(treepane);

		currentImage = novelCamera.getImage();
		viewpane = new ImagePanel();
		viewpane.setSize(256, 256);

		viewdeck = new CardLayout();

		viewpanel = new JPanel();
		viewpanel.setBounds(220, 10, 256, 256);
		viewpanel.setBackground(Color.white);
		viewpanel.add(viewpane);
		viewpanel.add(rotatingCube);

		viewdeck.addLayoutComponent(viewpane, "View");
		viewdeck.addLayoutComponent(rotatingCube, "Cube");

		viewpanel.setLayout(viewdeck);
		viewpanel.addMouseListener(clickListener);
		mainpane.add(viewpanel);

		viewdeck.show(viewpanel, "View");

		try {
			addCamera(new Camera("Camera 1",
								 new Vector4(0, 0, 0.400f),
								 new Vector4(0, 0, -1),
								 new Vector4(0, 1, 0),
								 0.043456f,
								 45,
								 ImageControl.getBufferedImage(getImage(
		 new URL("http://ibvh.fjeldstad.se/refs/camera01.png")), mainpane)));

			addCamera(new Camera("Camera 2",
								 new Vector4(0.400f, 0, -0.250f),
								 new Vector4(-0.400f, 0, 0.250f),
								 new Vector4(0, 1, 0),
								 0.043456f,
								 45,
								 ImageControl.getBufferedImage(getImage(
		 new URL("http://ibvh.fjeldstad.se/refs/camera02.png")), mainpane)));

			addCamera(new Camera("Camera 3",
								 new Vector4(-0.300f, 0, -0.200f),
								 new Vector4(0.300f, 0, 0.200f),
								 new Vector4(0, 1, 0),
								 0.043456f,
								 45,
								 ImageControl.getBufferedImage(getImage(
		 new URL("http://ibvh.fjeldstad.se/refs/camera03.png")), mainpane)));

			addCamera(new Camera("Camera 4",
								 new Vector4(0.250f, 0.200f, 0.200f),
								 new Vector4(-0.250f, -0.200f, -0.200f),
								 new Vector4(-0.250f, 0.5125f, -0.200f),
								 0.043456f,
								 45,
								 ImageControl.getBufferedImage(getImage(
		 new URL("http://ibvh.fjeldstad.se/refs/camera04.png")), mainpane)));

			addCamera(new Camera("Camera 5",
								 new Vector4(-0.150f, 0.200f, -0.300f),
								 new Vector4(0.150f, -0.200f, 0.300f),
								 new Vector4(0.150f, 0.5625f, 0.300f),
								 0.043456f,
								 45,
								 ImageControl.getBufferedImage(getImage(
		 new URL("http://ibvh.fjeldstad.se/refs/camera05.png")), mainpane)));

			addCamera(new Camera("Camera 6",
								 new Vector4(-0.300f, -0.150f, 0.200f),
								 new Vector4(0.300f, 0.150f, -0.200f),
								 new Vector4(-0.3196f, 0.92329f, 0.21307f),
								 0.043456f,
								 45,
								 ImageControl.getBufferedImage(getImage(
		 new URL("http://ibvh.fjeldstad.se/refs/camera06.png")), mainpane)));
		}
		catch (MalformedURLException ex) {
		}

		mainpane.setLayout(null);
		setSize(490, 280);
		mainpane.setSize(490, 280);
		mainpane.setVisible(true);
		setVisible(true);
	}

	public void valueChanged(TreeSelectionEvent e) {
		DefaultMutableTreeNode node =
			(DefaultMutableTreeNode) tree.getLastSelectedPathComponent();

		if (node != null &&
			node != sceneNode &&
			node != refViewsNode &&
			!vhcreator.isRunning()) {

			// Camera camera = (Camera) node.getUserObject();
			// Update view with selected camera
			currentImage = ((Camera) node.getUserObject()).getImage();
			viewdeck.show(viewpanel, "View");
			viewpane.repaint();
		}
	}

	/**
	 * Adds a new <code>Camera</code> to the scene.
	 *
	 * @param newCamera the new <code>Camera</code>
	 */
	private void addCamera(Camera newCamera) {
		DefaultMutableTreeNode childNode =
                new DefaultMutableTreeNode(newCamera);
        treeModel.insertNodeInto(childNode, refViewsNode,
                                 refViewsNode.getChildCount());
        tree.scrollPathToVisible(new TreePath(childNode.getPath()));
		tree.clearSelection();
		tree.addSelectionPath(
			new TreePath(refViewsNode.getLastLeaf().getPath()));
		refCameras.add(newCamera);
	}

	/**
	 * Starts the calculation of the visual hull based on the information
	 * in the available reference cameras.
	 */
	private void startCalculating() {

		progressMonitor = new ProgressMonitor(mainpane,
											  "Constructing visual hull...",
											  " ",
											  0,
											  100);
		progressMonitor.setProgress(0);
		progressMonitor.setMillisToDecideToPopup(0);
		progressMonitor.setMillisToPopup(0);

		vhcreator.startProcess();
		timer.start();
		tree.setEnabled(false);
		novelCamera.resetImage();
	}

	private class TimerListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			progressMonitor.setProgress(vhcreator.getProgress());
			progressMonitor.setNote(vhcreator.getNote());

			if (progressMonitor.isCanceled() || vhcreator.isFinished()) {
				progressMonitor.close();
				vhcreator.stopProcess();
				timer.stop();
				currentImage = novelCamera.getImage();
				viewpane.repaint();
				tree.setEnabled(true);
			}
		}
	}

	private class MouseClickListener extends MouseAdapter {

		public void mouseClicked(MouseEvent e) {
			if (!vhcreator.isRunning()) {
				if (!cubeVisible) {
					// Calculate the camera phi angle and send
					// it to rotatingCube
					float length = novelCamera.getPos().getLength();
					originalPhi =
						(float)Math.acos(novelCamera.getPos().y/length);
					rotatingCube.setCameraPhi(originalPhi);

					cubeVisible = !cubeVisible;
					viewdeck.show(viewpanel, "Cube");
					rotatingCube.repaint();
				}
				else {
					cubeVisible = !cubeVisible;
					currentImage = novelCamera.getImage();
					tree.clearSelection();
					tree.addSelectionPath(
						new TreePath(novelViewNode.getLastLeaf().getPath()));
					viewdeck.show(viewpanel, "View");
					viewpane.repaint();

					// Fetch the rotation matrix from rotatingCube
					// Rotate desired view
					// Rotate the camera of the novel view

					tempDirection = new Vector4(novelCamera.getDir().x,
												novelCamera.getDir().y,
												novelCamera.getDir().z, 1);

					tempPoint = new Vector4(novelCamera.getPos().x,
											novelCamera.getPos().y,
											novelCamera.getPos().z, 1);

					float length = novelCamera.getPos().getLength();
					sumAngle = rotatingCube.getAngles();

					//Calculate new pos
					originalTheta = (float)Math.atan2(novelCamera.getPos().x,
													  novelCamera.getPos().z);
					originalPhi =
						(float)Math.acos(novelCamera.getPos().y / length);
					novelCamera.getPos().setVector4(
						(float)(length*Math.sin(sumAngle.y + originalPhi) *
							Math.sin(originalTheta + sumAngle.x)),
						(float)(length*Math.cos(sumAngle.y + originalPhi)),
						(float)(length*Math.sin(sumAngle.y + originalPhi) *
							Math.cos(originalTheta + sumAngle.x)),
						1);

					//Calculate new dir
					novelCamera.getDir().setVector4(-novelCamera.getPos().x,
													-novelCamera.getPos().y,
													-novelCamera.getPos().z,
													1);
					novelCamera.getDir().normalize();

					//Calculate new up
					upY = new Vector4(0,1,0,1);
					projPoint = new Vector4(novelCamera.getDir().x,
											0,
											novelCamera.getDir().z,
											1);
					sideVector = Vector4.crossProduct(projPoint, upY);
					upVector = Vector4.crossProduct(sideVector,
													novelCamera.getDir());
					novelCamera.getUp().setVector4(upVector.x,
												   upVector.y,
												   upVector.z,
												   1);

					//Calculate the rotatation matrix
					CameraRot.createMatrices(novelCamera, tempDirection);
					rotateMatrix = CameraRot.getInvRotMatrix();

					vhcreator = new VisualHullCreator(refCameras, novelCamera);

					rotatingCube.setOrginalCube();
					rotatingCube.resetAngles();
					rotatingCube.setFirstTime(true);

					// Calculate visual hull
					startCalculating();
				}
			}
		}
	}

	class ImagePanel extends JPanel {
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setColor(Color.white);
  			g.drawRect(0,0,getWidth(), getHeight());
			g.drawImage(currentImage, 0, 0, this);
		}
	}
}
