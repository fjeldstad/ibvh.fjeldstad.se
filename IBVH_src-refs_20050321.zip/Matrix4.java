/* @(#)Matrix4.java 1.0 01/04/17
 * Stefan Gustavson, ITN-LiTH 2001 (stegu@itn.liu.se)
 * Modified by Jesper Carlson, Anders Fjeldstad, Daniel Enetoft, Kristofer G�rdeborg
 */

public class Matrix4 {

	/**
	* The matrix coefficients. Element <code>aij</code> is at row i, column j.
	*/
	public float a11,a12,a13,a14,
			a21,a22,a23,a24,
			a31,a32,a33,a34,
			a41,a42,a43,a44;

	/**
	* Default constructor, yields indentity matrix
	*/
	public Matrix4() {
		a11=1.0f; a12=0.0f; a13=0.0f; a14=0.0f;
		a21=0.0f; a22=1.0f; a23=0.0f; a24=0.0f;
		a31=0.0f; a32=0.0f; a33=1.0f; a34=0.0f;
		a41=0.0f; a42=0.0f; a43=0.0f; a44=1.0f;
	}

	/**
	* Matrix copy constructor, copies an existing matrix
	*/
	public Matrix4(Matrix4 m) {
		a11=m.a11; a12=m.a12; a13=m.a13; a14=m.a14;
		a21=m.a21; a22=m.a22; a23=m.a23; a24=m.a24;
		a31=m.a31; a32=m.a32; a33=m.a33; a34=m.a34;
		a41=m.a41; a42=m.a42; a43=m.a43; a44=m.a44;
	}

	/**
	* Factory method to create a transformation matrix for rotation around X
	* @param theta The rotation angle
	* @return A transformation matrix
	*/
	public static Matrix4 getRotateXInstance(float theta) {
		Matrix4 m = new Matrix4();
		m.a22=(float)Math.cos(theta);		m.a23=(float)Math.sin(-theta);
		m.a32=(float)Math.sin(theta); 		m.a33=(float)Math.cos(theta);
		return m;
	}

	/**
	* Factory method to create a transformation matrix for rotation around Y
	* @param theta The rotation angle
	* @return A transformation matrix
	*/
	public static Matrix4 getRotateYInstance(float theta) {
		Matrix4 m = new Matrix4();
		m.a11=(float)Math.cos(theta); 	m.a13=(float)Math.sin(theta);
		m.a31=(float)Math.sin(-theta); 	m.a33=(float)Math.cos(theta);
		return m;
	}

	/**
	* Factory method to create a transformation matrix for rotation around Z
	* @param theta The rotation angle
	* @return A transformation matrix
	*/
	public static Matrix4 getRotateZInstance(float theta) {
		Matrix4 m = new Matrix4();
		m.a11=(float)Math.cos(theta); 		m.a12=(float)Math.sin(-theta);
		m.a21=(float)Math.sin(theta); 		m.a22=(float)Math.cos(theta);
		return m;
	}

	/**
	* Factory method to create a transformation matrix for translation
	* @param tx The translation along the x dimension
	* @param ty The translation along the y dimension
	* @param tz The translation along the z dimension
	* @return A transformation matrix
	*/
	public static void getTranslateInstance(Matrix4 m,
											float tx,
											float ty,
											float tz) {
		m.a14=tx; m.a24=ty; m.a34=tz;
	}

	/**
	* Factory method to create a transformation matrix for uniform scaling
	* @param s The scaling factor
	* @return A transformation matrix
	*/
	public static Matrix4 getScaleInstance(float s) {
		Matrix4 m = new Matrix4();
		m.a11=s;
		m.a22=s;
		m.a33=s;
		return m;
	}

	/**
	* Factory method to create a transformation matrix for non-uniform scaling
	* @param sx The scaling factor along the x dimension
	* @param sy The scaling factor along the y dimension
	* @param sz The scaling factor along the z dimension
	* @return A transformation matrix
	*/
	public static Matrix4 getScaleInstance(float sx, float sy, float sz) {
		Matrix4 m = new Matrix4();
		m.a11=sx;
		m.a22=sy;
		m.a33=sz;
		return m;
	}

	/**
	* Copy the coefficient vaules from another matrix
	* @param m The matrix to copy
	*/
	public void set(Matrix4 m) {
		a11=m.a11; a12=m.a12; a13=m.a13; a14=m.a14;
		a21=m.a21; a22=m.a22; a23=m.a23; a24=m.a24;
		a31=m.a31; a32=m.a32; a33=m.a33; a34=m.a34;
		a41=m.a41; a42=m.a42; a43=m.a43; a44=m.a44;
	}



	/**
	* Rotating matrix
	* @param m1 The first (left) matrix for the multiplication
	* @param m2 The second (middle) matrix for the multiplication
	* @param m3 The third (right) matrix for the multiplication
	* @return The resulting matrix product
	*/
	public Matrix4 getRotMatrix(float phi, float theta, float sigma) {

		Matrix4 m = new Matrix4();
		m.getRotateXInstance(phi);
		this.mult(m);
		m.getRotateYInstance(theta);
		this.mult(m);
		m.getRotateZInstance(sigma);
		this.mult(m);
		return this;
	}

	/* Matrix multiply with a vector
	 * @param v The vector for the multiplication
	 * @return The resulting vector
	 */
	public static void mult(Matrix4 m, Vector4 v) {
		float x, y, z, w;
		x = m.a11*v.x+m.a12*v.y+m.a13*v.z+m.a14*v.w;
		y = m.a21*v.x+m.a22*v.y+m.a23*v.z+m.a24*v.w;
		z = m.a31*v.x+m.a32*v.y+m.a33*v.z+m.a34*v.w;
		w = m.a41*v.x+m.a42*v.y+m.a43*v.z+m.a44*v.w;
		v.x = x; v.y = y; v.z = z; v.w = w;
	}


	/**
	* Matrix multiply two matrices
	* @param m1 The first (left) matrix for the multiplication
	* @param m2 The second (right) matrix for the multiplication
	* @return The resulting matrix product
	*/
	public static Matrix4 mult(Matrix4 m1, Matrix4 m2) {
		Matrix4 m3 = new Matrix4();
		// An array for a(i,j) and loops would make this code more compact,
		// but slower.
		m3.a11 = m1.a11*m2.a11+m1.a12*m2.a21+m1.a13*m2.a31+m1.a14*m2.a41;
		m3.a12 = m1.a11*m2.a12+m1.a12*m2.a22+m1.a13*m2.a32+m1.a14*m2.a42;
		m3.a13 = m1.a11*m2.a13+m1.a12*m2.a23+m1.a13*m2.a33+m1.a14*m2.a43;
		m3.a14 = m1.a11*m2.a14+m1.a12*m2.a24+m1.a13*m2.a34+m1.a14*m2.a44;

		m3.a21 = m1.a21*m2.a11+m1.a22*m2.a21+m1.a23*m2.a31+m1.a24*m2.a41;
		m3.a22 = m1.a21*m2.a12+m1.a22*m2.a22+m1.a23*m2.a32+m1.a24*m2.a42;
		m3.a23 = m1.a21*m2.a13+m1.a22*m2.a23+m1.a23*m2.a33+m1.a24*m2.a43;
		m3.a24 = m1.a21*m2.a14+m1.a22*m2.a24+m1.a23*m2.a34+m1.a24*m2.a44;

		m3.a31 = m1.a31*m2.a11+m1.a32*m2.a21+m1.a33*m2.a31+m1.a34*m2.a41;
		m3.a32 = m1.a31*m2.a12+m1.a32*m2.a22+m1.a33*m2.a32+m1.a34*m2.a42;
		m3.a33 = m1.a31*m2.a13+m1.a32*m2.a23+m1.a33*m2.a33+m1.a34*m2.a43;
		m3.a34 = m1.a31*m2.a14+m1.a32*m2.a24+m1.a33*m2.a34+m1.a34*m2.a44;

		m3.a41 = m1.a41*m2.a11+m1.a42*m2.a21+m1.a43*m2.a31+m1.a44*m2.a41;
		m3.a42 = m1.a41*m2.a12+m1.a42*m2.a22+m1.a43*m2.a32+m1.a44*m2.a42;
		m3.a43 = m1.a41*m2.a13+m1.a42*m2.a23+m1.a43*m2.a33+m1.a44*m2.a43;
		m3.a44 = m1.a41*m2.a14+m1.a42*m2.a24+m1.a43*m2.a34+m1.a44*m2.a44;

		return m3;
	}

    /**
    * Matrix multiply two matrices
    * @param m2 The second (right) matrix for the multiplication
    * @return The resulting matrix product
    */
	public void mult(Matrix4 m2) {
		float f11,f12,f13,f14,f21,f22,f23,f24,f31,f32,f33,f34,f41,f42,f43,f44;
		f11 = this.a11*m2.a11+this.a12*m2.a21+this.a13*m2.a31+this.a14*m2.a41;
		f12 = this.a11*m2.a12+this.a12*m2.a22+this.a13*m2.a32+this.a14*m2.a42;
		f13 = this.a11*m2.a13+this.a12*m2.a23+this.a13*m2.a33+this.a14*m2.a43;
		f14 = this.a11*m2.a14+this.a12*m2.a24+this.a13*m2.a34+this.a14*m2.a44;

		f21 = this.a21*m2.a11+this.a22*m2.a21+this.a23*m2.a31+this.a24*m2.a41;
		f22 = this.a21*m2.a12+this.a22*m2.a22+this.a23*m2.a32+this.a24*m2.a42;
		f23 = this.a21*m2.a13+this.a22*m2.a23+this.a23*m2.a33+this.a24*m2.a43;
		f24 = this.a21*m2.a14+this.a22*m2.a24+this.a23*m2.a34+this.a24*m2.a44;

		f31 = this.a31*m2.a11+this.a32*m2.a21+this.a33*m2.a31+this.a34*m2.a41;
		f32 = this.a31*m2.a12+this.a32*m2.a22+this.a33*m2.a32+this.a34*m2.a42;
		f33 = this.a31*m2.a13+this.a32*m2.a23+this.a33*m2.a33+this.a34*m2.a43;
		f34 = this.a31*m2.a14+this.a32*m2.a24+this.a33*m2.a34+this.a34*m2.a44;

		f41 = this.a41*m2.a11+this.a42*m2.a21+this.a43*m2.a31+this.a44*m2.a41;
		f42 = this.a41*m2.a12+this.a42*m2.a22+this.a43*m2.a32+this.a44*m2.a42;
		f43 = this.a41*m2.a13+this.a42*m2.a23+this.a43*m2.a33+this.a44*m2.a43;
		f44 = this.a41*m2.a14+this.a42*m2.a24+this.a43*m2.a34+this.a44*m2.a44;

		this.a11 = f11; this.a12 = f12; this.a13 = f13; this.a14 = f14;
		this.a21 = f21; this.a22 = f22; this.a23 = f23; this.a24 = f24;
		this.a31 = f31; this.a32 = f32; this.a33 = f33; this.a34 = f34;
		this.a41 = f41; this.a42 = f42; this.a43 = f43; this.a44 = f44;
	}
}
