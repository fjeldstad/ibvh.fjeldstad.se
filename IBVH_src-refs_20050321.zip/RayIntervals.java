import java.util.Vector;

/**
 * This class can contain a <code>Ray3D</code> together with a number of
 * <code>Interval1D</code>s. This tuple represents a collection of intervals
 * along the ray. The intervals should be defined in terms of the parameter
 * of the ray.
 */

public class RayIntervals {
	
	/** The ray. */
	private Ray3D ray;
	/** Intervals along the ray. */
	private Vector intervals;
	
	/** 
	 * Creates an empty <code>RayIntervals</code> 
	 */
	public RayIntervals() {
	}
	
	/**
	 * Creates a new <code>RayIntervals</code> object and sets its ray
	 * to the supplied one.
	 *
	 * @param ray the new ray.
	 */
	public RayIntervals(Ray3D ray) {
		this.ray = ray;
		intervals = new Vector(1,1);
		intervals.addElement(new Interval1D());
	}
	
	/**
	 * Returns the current ray.
	 *
	 * @return the ray.
	 */
	public Ray3D getRay() {
		return ray;
	}
	
	/**
	 * Returns the current intervals along the ray.
	 *
	 * @return the intervals.
	 */
	public Vector getIntervals() {
		return intervals;
	}
}