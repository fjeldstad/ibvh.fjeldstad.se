import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.swing.border.*;

/**
 * This class is a dialog used to create new <code>Camera</code>s and
 * edit existing ones.
 */

public class CameraDialog extends JDialog implements ActionListener {

	private JPanel mainpane;
	private JButton chooseFileButton, saveButton;
	private JFileChooser fc;
	private ExampleFileFilter fileFilter;
	private Frame parent;
	private boolean firstTimeOpened;
	private ImageIcon thumbnail;
	private String imageFilename;
	private BufferedImage image;
	private JLabel thumb;

	private JLabel titleLabel;
	private JTextField titleField;

	private JPanel posPanel;
	private JLabel xPosLabel, yPosLabel, zPosLabel;
	private JTextField xPosField, yPosField, zPosField;

	private JPanel dirPanel;
	private JLabel xDirLabel, yDirLabel, zDirLabel;
	private JTextField xDirField, yDirField, zDirField;

	private JPanel upPanel;
	private JLabel xUpLabel, yUpLabel, zUpLabel;
	private JTextField xUpField, yUpField, zUpField;

	private JPanel miscPanel;
	private JLabel focalLengthLabel, fovLabel;
	private JTextField focalLengthField, fovField;

	private boolean confirmPressed;
	private byte currentMode;
	private final byte NONE = 0;
	private final byte NEW_CAMERA = 1;
	private final byte EDIT_CAMERA = 2;

	private Camera currentCamera;

	/**
	 * Creates an empty <code>CameraDialog</code>.
	 */
	public CameraDialog() {
		this(null, true);
	}

	/**
	 * Creates a <code>CameraDialog</code> with the specified parent frame
	 * and modal setting.
	 *
	 * @param parent the parent <code>Frame</code> of this dialog.
	 * @param modal whether the dialog should be modal or not.
	 */
	public CameraDialog(Frame parent, boolean modal) {
		super(parent, modal);
		this.parent = parent;

		firstTimeOpened = true;
		confirmPressed = false;
		currentMode = NONE;

		mainpane = new JPanel();
		setContentPane(mainpane);

		titleLabel = new JLabel("Title:");
		titleLabel.setFont(IBVHApplication.DEFAULT_FONT);
		titleLabel.setBounds(10, 10, 128, 20);
		mainpane.add(titleLabel);
		titleField = new JTextField();
		titleField.setFont(IBVHApplication.DEFAULT_FONT);
		titleField.setBounds(10, 30, 128, 20);
		mainpane.add(titleField);

		chooseFileButton = new JButton("Choose file...");
		chooseFileButton.setFont(IBVHApplication.DEFAULT_FONT);
		chooseFileButton.setBounds(10, 60, 128, 20);
		chooseFileButton.addActionListener(this);
		mainpane.add(chooseFileButton);

		thumbnail = new ImageIcon();
		thumb = new JLabel(thumbnail);
		thumb.setBounds(10, 90, 128, 96);
		mainpane.add(thumb);
		thumb.setVisible(false);

		fileFilter = new ExampleFileFilter();
		fileFilter.addExtension("jpg");
		fileFilter.setDescription("JPEG Images");

		buildPanels();

		saveButton = new JButton("Save camera");
		saveButton.setFont(IBVHApplication.DEFAULT_FONT);
		saveButton.setBounds(10, 232, 128, 20);
		saveButton.addActionListener(this);
		mainpane.add(saveButton);

		fc = new JFileChooser();
		fc.setFileFilter(fileFilter);

		mainpane.setLayout(null);
		setResizable(false);
		setSize(430, 300);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == chooseFileButton) {
			int optionVal = fc.showOpenDialog(CameraDialog.this);
			if (optionVal == JFileChooser.APPROVE_OPTION) {
				imageFilename = fc.getSelectedFile().getPath();
				image = ImageControl.getBufferedImage(imageFilename, mainpane);
				thumbnail.setImage(image.getScaledInstance(128,
														   96,
														   Image.SCALE_FAST));
				thumb.setVisible(true);
			}
		}
		if (e.getSource() == saveButton) {
			if (currentMode == EDIT_CAMERA) {
				// Save changes to the loaded camera
				saveCurrentCamera();
			}
			confirmPressed = true;
			currentMode = NONE;
			this.setVisible(false);
		}
	}

	/**
	 * Shows this <code>CameraDialog</code> as an empty dialog.
	 */
	public void showNewCamera() {
		setTitle("New camera");
		confirmPressed = false;
		currentMode = NEW_CAMERA;
		if (firstTimeOpened) {
			firstTimeOpened = false;
			centerOverParent();
		}
		setVisible(true);
	}

	/**
	 * Shows this <code>CameraDialog</code> filled with the information from
	 * the specified <code>Camera</code>.
	 *
	 * @param cam the <code>Camera</code> to edit.
	 */
	public void showEditCamera(Camera cam) {
		setTitle("Edit camera");
		confirmPressed = false;
		currentMode = EDIT_CAMERA;
		if (firstTimeOpened) {
			firstTimeOpened = false;
			centerOverParent();
		}
		editCamera(cam);
		setVisible(true);
	}

	/**
	 * Center this <code>CameraDialog</code> over its parent <code>Frame</code>.
	 */
	private void centerOverParent() {
		if (parent != null) {
			int parX = parent.getX();
			int parY = parent.getY();
			int parW = parent.getWidth();
			int parH = parent.getHeight();
			int thisW = getWidth();
			int thisH = getHeight();

			int thisX = parX + parW / 2 - thisW / 2;
			int thisY = parY + parH / 2 - thisH / 2;

			setLocation(thisX, thisY);
		}
	}

	private void buildPanels() {
				// Position panel
		posPanel = new JPanel();
		posPanel.setLayout(null);
		posPanel.setBounds(148, 10, 128, 116);
		posPanel.setBorder(new TitledBorder(LineBorder.createGrayLineBorder(),
						   					"Position",
						   					TitledBorder.DEFAULT_POSITION,
						   					TitledBorder.DEFAULT_JUSTIFICATION,
						   					IBVHApplication.DEFAULT_FONT));
		xPosLabel = new JLabel("X:");
		yPosLabel = new JLabel("Y:");
		zPosLabel = new JLabel("Z:");
		xPosField = new JTextField();
		yPosField = new JTextField();
		zPosField = new JTextField();
		xPosLabel.setFont(IBVHApplication.DEFAULT_FONT);
		yPosLabel.setFont(IBVHApplication.DEFAULT_FONT);
		zPosLabel.setFont(IBVHApplication.DEFAULT_FONT);
		xPosField.setFont(IBVHApplication.DEFAULT_FONT);
		yPosField.setFont(IBVHApplication.DEFAULT_FONT);
		zPosField.setFont(IBVHApplication.DEFAULT_FONT);
		xPosLabel.setBounds(10, 20, 15, 20);
		yPosLabel.setBounds(10, 50, 15, 20);
		zPosLabel.setBounds(10, 80, 15, 20);
		xPosField.setBounds(25, 20, 90, 20);
		yPosField.setBounds(25, 50, 90, 20);
		zPosField.setBounds(25, 80, 90, 20);
		posPanel.add(xPosLabel);
		posPanel.add(yPosLabel);
		posPanel.add(zPosLabel);
		posPanel.add(xPosField);
		posPanel.add(yPosField);
		posPanel.add(zPosField);
		mainpane.add(posPanel);

		// Direction panel
		dirPanel = new JPanel();
		dirPanel.setLayout(null);
		dirPanel.setBounds(286, 10, 128, 116);
		dirPanel.setBorder(new TitledBorder(LineBorder.createGrayLineBorder(),
						   					"View direction",
						   					TitledBorder.DEFAULT_POSITION,
						   					TitledBorder.DEFAULT_JUSTIFICATION,
						   					IBVHApplication.DEFAULT_FONT));
		xDirLabel = new JLabel("X:");
		yDirLabel = new JLabel("Y:");
		zDirLabel = new JLabel("Z:");
		xDirField = new JTextField();
		yDirField = new JTextField();
		zDirField = new JTextField();
		xDirLabel.setFont(IBVHApplication.DEFAULT_FONT);
		yDirLabel.setFont(IBVHApplication.DEFAULT_FONT);
		zDirLabel.setFont(IBVHApplication.DEFAULT_FONT);
		xDirField.setFont(IBVHApplication.DEFAULT_FONT);
		yDirField.setFont(IBVHApplication.DEFAULT_FONT);
		zDirField.setFont(IBVHApplication.DEFAULT_FONT);
		xDirLabel.setBounds(10, 20, 15, 20);
		yDirLabel.setBounds(10, 50, 15, 20);
		zDirLabel.setBounds(10, 80, 15, 20);
		xDirField.setBounds(25, 20, 90, 20);
		yDirField.setBounds(25, 50, 90, 20);
		zDirField.setBounds(25, 80, 90, 20);
		dirPanel.add(xDirLabel);
		dirPanel.add(yDirLabel);
		dirPanel.add(zDirLabel);
		dirPanel.add(xDirField);
		dirPanel.add(yDirField);
		dirPanel.add(zDirField);
		mainpane.add(dirPanel);

		// Up panel
		upPanel = new JPanel();
		upPanel.setLayout(null);
		upPanel.setBounds(148, 136, 128, 116);
		upPanel.setBorder(new TitledBorder(LineBorder.createGrayLineBorder(),
						   					"Up direction",
						   					TitledBorder.DEFAULT_POSITION,
						   					TitledBorder.DEFAULT_JUSTIFICATION,
						   					IBVHApplication.DEFAULT_FONT));
		xUpLabel = new JLabel("X:");
		yUpLabel = new JLabel("Y:");
		zUpLabel = new JLabel("Z:");
		xUpField = new JTextField();
		yUpField = new JTextField();
		zUpField = new JTextField();
		xUpLabel.setFont(IBVHApplication.DEFAULT_FONT);
		yUpLabel.setFont(IBVHApplication.DEFAULT_FONT);
		zUpLabel.setFont(IBVHApplication.DEFAULT_FONT);
		xUpField.setFont(IBVHApplication.DEFAULT_FONT);
		yUpField.setFont(IBVHApplication.DEFAULT_FONT);
		zUpField.setFont(IBVHApplication.DEFAULT_FONT);
		xUpLabel.setBounds(10, 20, 15, 20);
		yUpLabel.setBounds(10, 50, 15, 20);
		zUpLabel.setBounds(10, 80, 15, 20);
		xUpField.setBounds(25, 20, 90, 20);
		yUpField.setBounds(25, 50, 90, 20);
		zUpField.setBounds(25, 80, 90, 20);
		upPanel.add(xUpLabel);
		upPanel.add(yUpLabel);
		upPanel.add(zUpLabel);
		upPanel.add(xUpField);
		upPanel.add(yUpField);
		upPanel.add(zUpField);
		mainpane.add(upPanel);

		// Misc. panel
		miscPanel = new JPanel();
		miscPanel.setLayout(null);
		miscPanel.setBounds(286, 136, 128, 116);
		miscPanel.setBorder(new TitledBorder(LineBorder.createGrayLineBorder(),
						   					"Miscellaneous",
						   					TitledBorder.DEFAULT_POSITION,
						   					TitledBorder.DEFAULT_JUSTIFICATION,
						   					IBVHApplication.DEFAULT_FONT));
		focalLengthLabel = new JLabel("Focal length:");
		fovLabel = new JLabel("Field of view:");
		focalLengthField = new JTextField();
		fovField = new JTextField();
		focalLengthLabel.setFont(IBVHApplication.DEFAULT_FONT);
		fovLabel.setFont(IBVHApplication.DEFAULT_FONT);
		focalLengthField.setFont(IBVHApplication.DEFAULT_FONT);
		fovField.setFont(IBVHApplication.DEFAULT_FONT);
		focalLengthLabel.setBounds(10, 20, 105, 20);
		fovLabel.setBounds(10, 60, 105, 20);
		focalLengthField.setBounds(10, 40, 105, 20);
		fovField.setBounds(10, 80, 105, 20);
		miscPanel.add(focalLengthLabel);
		miscPanel.add(fovLabel);
		miscPanel.add(focalLengthField);
		miscPanel.add(fovField);
		mainpane.add(miscPanel);
	}

	/**
	 * Clears all the fields in this <code>CameraDialog</code>.
	 */
	public void clearAll() {
		titleField.setText("");
		xPosField.setText("");
		yPosField.setText("");
		zPosField.setText("");
		xDirField.setText("");
		yDirField.setText("");
		zDirField.setText("");
		xUpField.setText("");
		yUpField.setText("");
		zUpField.setText("");
		focalLengthField.setText("");
		fovField.setText("");

		thumb.setVisible(false);
		image = null;
	}

	/**
	 * Returns whether the confirm (save) button was pressed or not.
	 *
	 * @return true if the confirm button was pressed.
	 */
	public boolean isConfirmed() {
		return confirmPressed;
	}

	/**
	 * Returns a new <code>Camera</code> based on the information that is
	 * currently contained in this <code>CameraDialog</code>.
	 *
	 * @return a new <code>Camera</code> object.
	 */
	public Camera getNewCamera() {
		return new Camera(titleField.getText(),
						  new Vector4(Float.parseFloat(xPosField.getText()),
						   			  Float.parseFloat(yPosField.getText()),
						   			  Float.parseFloat(zPosField.getText())),
						  new Vector4(Float.parseFloat(xDirField.getText()),
						   			  Float.parseFloat(yDirField.getText()),
						   			  Float.parseFloat(zDirField.getText())),
						  new Vector4(Float.parseFloat(xUpField.getText()),
						   			  Float.parseFloat(yUpField.getText()),
						   			  Float.parseFloat(zUpField.getText())),
						  Float.parseFloat(focalLengthField.getText()),
						  Float.parseFloat(fovField.getText()),
						  image);
	}

	/**
	 * Fills this <code>CameraDialog</code> with the information from the
	 * specified <code>Camera</code> object.
	 *
	 * @param c the <code>Camera</code> containing the desired information.
	 */
	private void editCamera(Camera c) {
		titleField.setText(c.getTitle());
		xPosField.setText(Float.toString(c.getPos().x));
		yPosField.setText(Float.toString(c.getPos().y));
		zPosField.setText(Float.toString(c.getPos().z));
		xDirField.setText(Float.toString(c.getDir().x));
		yDirField.setText(Float.toString(c.getDir().y));
		zDirField.setText(Float.toString(c.getDir().z));
		xUpField.setText(Float.toString(c.getUp().x));
		yUpField.setText(Float.toString(c.getUp().y));
		zUpField.setText(Float.toString(c.getUp().z));
		focalLengthField.setText(Float.toString(c.getFocalLength()));
		fovField.setText(Float.toString(c.getFov()));
		image = c.getImage();
		thumbnail.setImage(image.getScaledInstance(128,
												   96,
												   Image.SCALE_FAST));
		thumb.setVisible(true);

		currentCamera = c;
	}

	/**
	 * Updates the current <code>Camera</code> with the current information
	 * of this <code>CameraDialog</code>.
	 */
	private void saveCurrentCamera() {
		currentCamera.update(titleField.getText(),
						     new Vector4(Float.parseFloat(xPosField.getText()),
						   			     Float.parseFloat(yPosField.getText()),
						   			     Float.parseFloat(zPosField.getText())),
						     new Vector4(Float.parseFloat(xDirField.getText()),
						   	   		     Float.parseFloat(yDirField.getText()),
						   	   		     Float.parseFloat(zDirField.getText())),
						     new Vector4(Float.parseFloat(xUpField.getText()),
						   			     Float.parseFloat(yUpField.getText()),
						   			     Float.parseFloat(zUpField.getText())),
						     Float.parseFloat(focalLengthField.getText()),
						     Float.parseFloat(fovField.getText()),
						     image);
	}
}
