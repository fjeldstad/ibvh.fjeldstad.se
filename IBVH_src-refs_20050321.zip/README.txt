IBVH

A project done in the course Image-based Rendering TNM078 at
Link�ping University, 2005

Authors:
Jesper Carlson, jesca144@student.liu.se
Daniel Enetoft, danen736@student.liu.se
Anders Fjeldstad, andfj645@student.liu.se
Kristofer G�rdeborg, kriga592@student.liu.se

Description:
IBVH is a IBR project aiming to implement the simple algorithm of creating
image-based visual hulls as described by Matusik et al. in the paper
[Image Based Visual Hulls. Matusik et al. SIGGRAPH'2000.]

The application visualize the Visual Hull by creating a depth map. We have also
implemented a simple, not entirely functional shading algorithm. It is possible
to see the results from this shading by uncomment appropriate lines in
VisualHullCreator.java and then recompile the project.

How to use the application:
The application has by default six reference cameras showing different views of
a milk carton. To create the visual hull simply press the left mouse button on
the black picture in the novel view camera and rotate the camera to a desired
location. Press again with right mouse button and the process of calculating the
visual hull will begin. The process of creating a visual hull can take several
minutes depending on the hardware available.

It is possible to create a visual hull of any convex object. In addition to the
images you need to know the position of the camera, the direction, the
up-vector, field of view and focal length. The object is assumed to be
positioned in the origin of 3D space.
