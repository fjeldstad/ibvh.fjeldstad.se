/**
 * This is a class that creates rays in 3d space
 */
public class Compute3DRay {
	
	/**
	 * Creates a new <code>Ray3D</code> that starts in the supplied 
	 * <code>Cameras</code> position and get a direction depending on through 
	 * which pixel it is choosen to go.
	 *
	 * @param camera the camera from who the ray get its starting point
	 * @param x the pixel number in horizontal way
	 * @param y the pixel number in vertical way
	 * 
	 * @return the ray.
	 */
	static Ray3D compute3DRay(Camera camera, int x, int y) {

		Vector4 pos = new Vector4(camera.getPos());
		Vector4 normDir = new Vector4(camera.getDir());
		Vector4 normUp = new Vector4(camera.getUp());
		float fov = camera.getFov();
		float focalLength = camera.getFocalLength();

		//Move (0,0) to the middle of the picture
		int pixelX = x-camera.getImage().getWidth()/2;
		int pixelY = camera.getImage().getHeight()/2 - y;

		// (0,0, focal length) i 3d-coordinates
		Vector4 centrumPoint = new Vector4();

		centrumPoint.x = pos.x + normDir.x * focalLength;
		centrumPoint.y = pos.y + normDir.y * focalLength;
		centrumPoint.z = pos.z + normDir.z * focalLength;

		//distance in 2d space between (0,0) and given pixel
		float dxIn2d = (float)Math.tan(fov/2) * focalLength * 2 * pixelX/
							camera.getImage().getWidth();
		float dyIn2d = (float)Math.tan(fov/2) * focalLength * 2 * pixelY/
							camera.getImage().getHeight();

		Vector4 sideVector = Vector4.crossProduct(normUp, normDir);
        sideVector.normalize();

		Vector4 deltaIn3d = new Vector4();

		//distance in 3d space between (0,0, focal length) and given pixel
		deltaIn3d.x = -sideVector.x * dxIn2d + normUp.x * dyIn2d;
		deltaIn3d.y = -sideVector.y * dxIn2d + normUp.y * dyIn2d;
		deltaIn3d.z = -sideVector.z * dxIn2d + normUp.z * dyIn2d;


		Vector4 pixelIn3D = new Vector4();
		
		//pixel in 3D coordinates
		pixelIn3D.x = centrumPoint.x + deltaIn3d.x;
		pixelIn3D.y = centrumPoint.y + deltaIn3d.y;
		pixelIn3D.z = centrumPoint.z + deltaIn3d.z;

		Vector4 rayDir = new Vector4();

		rayDir = pixelIn3D.sub(pos);

		rayDir.normalize();

		Ray3D r3D = new Ray3D(pos,rayDir);

		return r3D;
	}
}
