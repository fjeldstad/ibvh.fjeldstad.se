import java.awt.*;
import java.awt.image.*;

/**
 * This class icludes methods for reading images from file
 */

public class ImageControl {

  	/**
  	 * Reads a image from file, making it a buffered image.
  	 *
  	 * @param imagefile the local file specifing the image
  	 * @param c a graphical component to use
  	 * @return the buffered image of the local file
  	 */
	public static BufferedImage getBufferedImage(String imageFile,
                                               Component c) {
	    Image image = c.getToolkit().getImage(imageFile);
	    waitForImage(image, c);

	    BufferedImage bufferedImage =
	      new BufferedImage(image.getWidth(c), image.getHeight(c),
	                        BufferedImage.TYPE_INT_RGB);

	    Graphics2D g2d = bufferedImage.createGraphics();
	    g2d.drawImage(image, 0, 0, c);
	    return(bufferedImage);
	}

	public static BufferedImage getBufferedImage(Image image, Component c) {
	    waitForImage(image, c);

	    BufferedImage bufferedImage =
	      new BufferedImage(image.getWidth(c), image.getHeight(c),
	                        BufferedImage.TYPE_INT_RGB);

	    Graphics2D g2d = bufferedImage.createGraphics();
	    g2d.drawImage(image, 0, 0, c);
	    return(bufferedImage);
	}

	/**
	* Take an Image associated with a file, and wait until it is
	* done loading (just a simple application of MediaTracker).
	* If you are loading multiple images, don't use this
	* consecutive times; instead, use the version that takes
	* an array of images.
	*/
	public static boolean waitForImage(Image image, Component c) {
		MediaTracker tracker = new MediaTracker(c);
		tracker.addImage(image, 0);
		try {
		  tracker.waitForAll();
		} catch(InterruptedException ie) {}
		return(!tracker.isErrorAny());
	}

}