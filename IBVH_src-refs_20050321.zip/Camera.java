import java.awt.image.BufferedImage;

/**
 * This class represents a viewpoint and a (limited) view plane.
 */

public class Camera {

	public static final int DEFAULT_IMAGE_WIDTH = 256;
	public static final int DEFAULT_IMAGE_HEIGHT = 256;

	String title;
	Vector4 position;
	Vector4 direction;
	Vector4 up;
	float focalLength = 0;
	float fov = 0;
	BufferedImage image = null;
	double deg2rad = Math.PI / 180.0;

	/**
	 * Creates an empty <code>Camera</code>.
	 */
	public Camera() {
		position = new Vector4();
		direction = new Vector4();
		up = new Vector4();

		// Create empty image with default dimensions
		image = new BufferedImage(DEFAULT_IMAGE_WIDTH,
								  DEFAULT_IMAGE_HEIGHT,
								  BufferedImage.TYPE_INT_RGB);
	}

	/**
	 * Creates a new <code>Camera</code> with the specified parameters.
	 *
	 * @param title the title of the <code>Camera</code>.
	 * @param pos the position of the <code>Camera</code> in world coordinates.
	 * @param dir the direction of the <code>Camera</code> relative to the
	 *            view point.
	 * @param up the "up" direction of the <code>Camera</code> relative to the
	 *			  view point.
	 * @param focal the focal length (in meters, assuming world coordinate
	 *            units is meters) of the <code>Camera</code>.
	 * @param fov the field-of-view of the <code>Camera</code> in degrees.
	 * @param im the <code>BufferedImage</code> representing the limited view
	 *            plane of this <code>Camera</code>.
	 */
	public Camera(String title,
				  Vector4 pos,
				  Vector4 dir,
				  Vector4 up,
				  float focal,
				  float fov,
				  BufferedImage im) {

		this.title = title;
		this.position = pos;
		this.direction = dir;
		this.up = up;
		this.focalLength = focal;
		this.fov = (float)Math.toRadians(fov);
		this.image = im;

		// Normalize vectors
		this.direction.normalize();
		this.up.normalize();
	}

	/**
	 * Creates an empty <code>Camera</code> with the specified title.
	 *
	 * @param title the title of the <code>Camera</code>.
	 */
	public Camera(String title) {
		this();
		this.title = title;
	}

	/**
	 * Updates this <code>Camera</code> with the supplied data.
	 *
	 * @param title the title of the <code>Camera</code>.
	 * @param pos the position of the <code>Camera</code> in world coordinates.
	 * @param dir the direction of the <code>Camera</code> relative to the
	 *            view point.
	 * @param up the "up" direction of the <code>Camera</code> relative to the
	 *			  view point.
	 * @param focal the focal length (in meters, assuming world coordinate
	 *            units is meters) of the <code>Camera</code>.
	 * @param fov the field-of-view of the <code>Camera</code> in degrees.
	 * @param im the <code>BufferedImage</code> representing the limited view
	 *            plane of this <code>Camera</code>.
	 */
	public void update(String title,
					   Vector4 pos,
					   Vector4 dir,
				       Vector4 up,
					   float focal,
					   float fov,
					   BufferedImage im) {

		this.title = title;
		this.position = pos;
		this.direction = dir;
		this.up = up;
		this.focalLength = focal;
		this.fov = (float)Math.toRadians(fov);
		this.image = im;

		// Normalize vectors
		this.direction.normalize();
		this.up.normalize();
	}

	/**
	 * Returns the title.
	 *
	 * @return the title.
	 */
	public String toString() {
		return title;
	}

	/**
	 * Returns the title.
	 *
	 * @return the title.
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Returns the position in world coordinates.
	 *
	 * @return the position.
	 */
	public Vector4 getPos() {
		return position;
	}

	/**
	 * Returns the view direction relative to the view point.
	 *
	 * @return the view direction.
	 */
	public Vector4 getDir() {
		return direction;
	}

	/**
	 * Returns the "up" direction relative to the view point.
	 *
	 * @return the "up" direction.
	 */
	public Vector4 getUp() {
		return up;
	}

	/**
	 * Returns the focal length (in meters).
	 *
	 * @return the focal length.
	 */
	public float getFocalLength() {
		return focalLength;
	}

	/**
	 * Returns the field-of-view (in degrees).
	 *
	 * @return the field-of-view.
	 */
	public float getFov() {
		return fov;
	}

	/**
	 * Returns the image seen by the <code>Camera</code>.
	 *
	 * @return the image of this <code>Camera</code>.
	 */
	public BufferedImage getImage() {
		return image;
	}

	/**
	 * Resets the image seen by this <code>Camera</code> to an empty one.
	 */
	public void resetImage() {
		image = new BufferedImage(Camera.DEFAULT_IMAGE_WIDTH,
								  Camera.DEFAULT_IMAGE_HEIGHT,
								  BufferedImage.TYPE_INT_RGB);
	}

	/**
	 * Returns the color of the specified pixel in the image of this camera.
	 *
	 * @param x the X-coordinate of the pixel.
	 * @param y the Y-coordinate of the pixel.
	 * @return the color of the specified pixel as an int with ARGB format and
	 * 		   8 bits per component. If the supplied coordinates lie outside
	 *		   of the image, Integer.MAX_VALUE is returned.
	 */
	public int getRGB(int x, int y) {
		if (x < 0 || x > image.getWidth()-1 || y < 0 || y > image.getHeight()-1) {
			return Integer.MAX_VALUE;
		}
		else {
			return image.getRGB(x, y);
		}
	}
}
